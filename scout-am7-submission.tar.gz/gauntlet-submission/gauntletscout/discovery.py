"""Deterministic tool discovery, classification, schema-checked argument building.

No model call happens here. The set returned by list_tool_defs() is the only source
of callable names: anything else is refused by ToolGuard (zero hallucinated calls).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

# Never call tools that look like operator controls or that only text inside a clue told us about.
DENY_RE = re.compile(r"(override|admin|reset|delete|debug|operator|not for agents|leaderboard|shutdown)", re.I)

CLASS_RULES: list[tuple[str, re.Pattern[str]]] = [
    ("submit", re.compile(r"submit", re.I)),
    ("thought", re.compile(r"broadcast_thought|thought", re.I)),
    ("time", re.compile(r"time_remaining|\btime\b", re.I)),
    ("image", re.compile(r"^image_|arena\.image\.", re.I)),
    ("challenge", re.compile(r"get_challenge", re.I)),
    ("clue", re.compile(r"clue", re.I)),
    ("search", re.compile(r"search|browse|fetch_url", re.I)),
]


@dataclass
class ToolInfo:
    name: str
    description: str
    schema: dict[str, Any]
    kind: str
    denied: bool = False
    dead: bool = False

    @property
    def properties(self) -> dict[str, Any]:
        props = self.schema.get("properties") if isinstance(self.schema, dict) else None
        return props if isinstance(props, dict) else {}

    @property
    def required(self) -> list[str]:
        req = self.schema.get("required") if isinstance(self.schema, dict) else None
        return [r for r in (req or []) if isinstance(r, str)]


def classify(name: str, description: str) -> str:
    for kind, rx in CLASS_RULES:
        if rx.search(name):
            return kind
    return "unknown"


def index_tools(tool_defs: list[Any]) -> dict[str, ToolInfo]:
    out: dict[str, ToolInfo] = {}
    for t in tool_defs:
        name = str(getattr(t, "name", "") or "").strip()
        if not name:
            continue
        desc = str(getattr(t, "description", "") or "")
        schema = getattr(t, "inputSchema", None) or {}
        out[name] = ToolInfo(name, desc, schema if isinstance(schema, dict) else {}, classify(name, desc),
                             denied=bool(DENY_RE.search(name) or DENY_RE.search(desc)))
    return out


_JSON_TYPES = {"string": str, "integer": int, "number": (int, float), "boolean": bool, "object": dict, "array": list}


def validate_args(info: ToolInfo, args: dict[str, Any]) -> str | None:
    """Minimal JSON-schema check: required present, top-level types match. Returns error or None."""
    for r in info.required:
        if r not in args or args[r] is None:
            return f"missing required arg {r!r}"
    for k, v in args.items():
        spec = info.properties.get(k)
        if spec is None:
            if info.properties and info.schema.get("additionalProperties") is False:
                return f"unexpected arg {k!r}"
            continue
        types = spec.get("type") or [a.get("type") for a in spec.get("anyOf", []) if isinstance(a, dict)]
        types = [types] if isinstance(types, str) else [t for t in types if t]
        if not types or v is None and "null" in types:
            continue
        py = tuple(x for t in types if t in _JSON_TYPES for x in (_JSON_TYPES[t] if isinstance(_JSON_TYPES[t], tuple) else (_JSON_TYPES[t],)))
        if py and not isinstance(v, py):
            return f"arg {k!r} has wrong type"
    return None


@dataclass
class Evidence:
    """Values the planner may feed into unknown tools (all derived from tool output, never invented names)."""
    numbers: list[str] = field(default_factory=list)
    tokens: list[str] = field(default_factory=list)
    entries: list[str] = field(default_factory=list)
    words: list[str] = field(default_factory=list)
    labels: dict[str, str] = field(default_factory=dict)  # 'Index topic: night shift' -> {'topic': 'night shift'}

    def absorb_result(self, res: dict) -> None:
        for k, v in res.items():
            if isinstance(v, str) and ("token" in k.lower() or "ticket" in k.lower()) and v not in self.tokens:
                self.tokens.append(v)

    def absorb(self, text: str) -> None:
        for m in re.finditer(r"(?:^|[\n.;]\s*)[A-Za-z ]{0,30}?\b([A-Za-z_]{2,20})\s*:\s*([A-Za-z0-9][A-Za-z0-9 _-]{0,40}?)\s*(?:$|[\n.;])", text):
            k = m.group(1).lower()
            if k not in self.labels and k not in ("intercept", "text", "error", "note", "message"):
                self.labels[k] = m.group(2).strip()
        for w in re.findall(r"'([A-Za-z_]{3,24})'", text):
            if w not in self.words:
                self.words.append(w)
        spelled = re.findall(r"\b(?:(?:zero|one|two|three|four|five|six|seven|eight|nine)\b[\s,-]*){3,8}", text, re.I)
        digits = {w: str(i) for i, w in enumerate("zero one two three four five six seven eight nine".split())}
        for run in spelled:  # 'PIN, spoken: six zero eight seven' -> 6087
            text += " " + "".join(digits[w.lower()] for w in re.findall(r"[a-z]+", run, re.I))
        for n in re.findall(r"\b\d{3,8}\b", text):
            if n not in self.numbers:
                self.numbers.append(n)
        for tok in re.findall(r"\b(?:tok|token|key|doc|rec)[-_][A-Za-z0-9]{2,}\b", text):
            if tok and tok not in self.tokens:
                self.tokens.append(tok)
        for e in re.findall(r"\b[a-z]+_[a-z_]+\b", text):
            if e not in self.entries and not e.startswith(("time_", "max_", "agent_", "clue_", "challenge_", "puzzle_", "required_")):
                self.entries.append(e)


def build_args(info: ToolInfo, agent_id: str, ev: Evidence, hint: str = "") -> list[dict[str, Any]]:
    """Candidate argument dicts for probing a tool, most plausible first (max 3)."""
    base: dict[str, Any] = {}
    if "agent_id" in info.properties or not info.properties:
        base["agent_id"] = agent_id
    variants: list[dict[str, Any]] = [dict(base)]
    for prop in info.required or [p for p in info.properties if p != "agent_id"][:1]:
        if prop == "agent_id":
            continue
        p = prop.lower()
        spec = info.properties.get(prop) or {}
        stem = p.split("_")[0]
        if p in ev.labels or stem in ev.labels:  # value stated in prose under the parameter's own name
            values = [ev.labels.get(p) or ev.labels[stem]]
        elif p.endswith("_id") and [t for t in ev.tokens if t.lower().startswith(stem)]:
            values = [t for t in ev.tokens if t.lower().startswith(stem)][-2:][::-1]
        elif isinstance(spec.get("enum"), list) and spec["enum"]:
            enum = [e for e in spec["enum"] if isinstance(e, (str, int))]
            seen = " ".join(ev.words).lower()
            values = sorted(enum, key=lambda e: str(e).lower() not in seen)[:2]
        elif "token" in p:
            values = ev.tokens[-2:][::-1]
        elif "code" in p or "pin" in p or "number" in p:
            values = ev.numbers[-3:][::-1]
        elif "entry" in p or "name" in p or "key" in p:
            values = ev.entries[:3]
        else:
            values = [hint or "key"]
        if not values:
            if prop in info.required:
                return []
            continue
        variants = [{**v, prop: val} for v in variants for val in values]
    from gauntletscout.schema import coerce_args
    variants = [coerce_args(info.schema, v) for v in variants]
    return [v for v in variants if validate_args(info, v) is None][:3]
