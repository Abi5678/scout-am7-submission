"""Static skill library: short playbooks keyed by puzzle features, retrieved at runtime.

The library is a frozen JSON file shipped in the package (gauntletscout/skills/library.json). Nothing here
writes anywhere or touches the network; eval/learn.py edits the file OFFLINE, only through accept/reject.

Playbook = {"id", "triggers": {"any": [regex...], "none": [regex...]}, "text": <=300 chars,
            "actions": {whitelisted knobs}, "origin", "version"}
Retrieval: a playbook matches if >=1 'any' regex hits the feature text and no 'none' regex does; ranked by
number of hits; at most K=2 playbooks / MAX_CHARS of text are injected (tokens are 5% of the score).
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

DEFAULT_PATH = Path(__file__).resolve().parent / "skills" / "library.json"
K = 2
MAX_TEXT = 300
MAX_CHARS = 480
# whitelisted behaviour knobs a playbook may set: name -> (type, lo, hi). Anything else fails validation.
ACTIONS: dict[str, tuple[type, int, int]] = {
    "consult_model": (bool, 0, 1),   # run the open model solve even when a decode looks confident
    "trust_model": (bool, 0, 1),     # the model's (non-penalised) answer may outrank a clean decode
    "max_clues": (int, 1, 40),       # fetch up to N clues (default 10)
    "clean_noise": (bool, 0, 1),     # also decode copies of long tokens with non-base64 characters stripped
    "tool_retries": (int, 0, 6),     # retries for required tools (default 3)
}
DATA_URI_RE = re.compile(r"data:image/[a-z]+;base64,[A-Za-z0-9+/=]+")


@dataclass
class Playbook:
    id: str
    triggers: dict[str, list[str]]
    text: str
    actions: dict[str, Any] = field(default_factory=dict)
    origin: str = "manual"
    version: int = 1

    def to_dict(self) -> dict[str, Any]:
        return {"id": self.id, "triggers": self.triggers, "text": self.text, "actions": self.actions,
                "origin": self.origin, "version": self.version}


def validate(d: Any) -> list[str]:
    if not isinstance(d, dict):
        return ["not an object"]
    errs = []
    if not re.fullmatch(r"[a-z0-9][a-z0-9_-]{1,40}", str(d.get("id") or "")):
        errs.append("bad id")
    trig = d.get("triggers")
    if not isinstance(trig, dict) or not isinstance(trig.get("any"), list) or not trig.get("any"):
        return errs + ["triggers.any must be a non-empty list"]
    for k in ("any", "none"):
        for rx in trig.get(k) or []:
            try:
                re.compile(str(rx))
            except re.error:
                errs.append(f"bad regex {rx!r}")
                continue
            if not isinstance(rx, str) or len(rx) > 120 or re.fullmatch(rx, "", re.I) is not None:
                errs.append(f"regex too broad/long {rx!r}")  # must not match the empty string
    text = d.get("text")
    if not isinstance(text, str) or not text.strip() or len(text) > MAX_TEXT:
        errs.append(f"text must be 1..{MAX_TEXT} chars")
    acts = d.get("actions") or {}
    if not isinstance(acts, dict):
        return errs + ["actions must be an object"]
    for k, v in acts.items():
        if k not in ACTIONS:
            errs.append(f"unknown action {k}")
            continue
        typ, lo, hi = ACTIONS[k]
        ok = isinstance(v, bool) if typ is bool else (isinstance(v, int) and not isinstance(v, bool) and lo <= v <= hi)
        if not ok:
            errs.append(f"bad value for {k}: {v!r}")
    return errs


def from_dict(d: dict[str, Any]) -> Playbook:
    return Playbook(d["id"], {"any": list(d["triggers"]["any"]), "none": list(d["triggers"].get("none") or [])},
                    d["text"], dict(d.get("actions") or {}), str(d.get("origin", "manual")), int(d.get("version", 1)))


def load(path: str | Path | None = None) -> list[Playbook]:
    """Read-only. SCOUT_SKILLS='' disables the library; SCOUT_SKILLS=<path> overrides (offline eval only)."""
    env = os.getenv("SCOUT_SKILLS")
    if path is None and env is not None:
        if not env.strip():
            return []
        path = env
    p = Path(path) if path else DEFAULT_PATH
    try:
        raw = json.loads(p.read_text())
    except (OSError, ValueError):
        return []
    return [from_dict(d) for d in (raw.get("playbooks") or [] if isinstance(raw, dict) else []) if not validate(d)]


def save(lib: list[Playbook], path: str | Path) -> None:  # offline (eval/learn.py) only
    Path(path).write_text(json.dumps({"version": 1, "playbooks": [pb.to_dict() for pb in lib]}, indent=2) + "\n")


def features(description: str = "", rules: str = "", clues: list[str] | None = None,
             required_tools: list[str] | None = None, n_clues: int | None = None, max_clues: int = 12) -> str:
    """The text triggers are matched against (the same function is used offline and at runtime)."""
    cl = [DATA_URI_RE.sub("[image]", str(c))[:400] for c in (clues or [])[:max_clues]]
    n = len(clues or []) if n_clues is None else n_clues
    return "\n".join([f"description: {description}", f"rules: {rules}",
                      f"required_tools: {' '.join(required_tools or [])}", f"n_clues={n}",
                      *(f"clue: {c}" for c in cl)])


def hits(pb: Playbook, feat: str) -> int:
    if any(re.search(rx, feat, re.I) for rx in pb.triggers.get("none") or []):
        return 0
    return sum(1 for rx in pb.triggers.get("any") or [] if re.search(rx, feat, re.I))


def retrieve(lib: list[Playbook], feat: str, k: int = K, max_chars: int = MAX_CHARS) -> list[Playbook]:
    scored = sorted(((h, i, pb) for i, pb in enumerate(lib) if (h := hits(pb, feat)) > 0), key=lambda x: (-x[0], x[1]))
    out: list[Playbook] = []
    used = 0
    for _, _, pb in scored:
        if len(out) >= k or used + len(pb.text) > max_chars:
            continue
        out.append(pb)
        used += len(pb.text)
    return out


def render(pbs: list[Playbook]) -> str:
    return ("PLAYBOOK (lessons from similar puzzles):\n" + "\n".join(f"- {pb.text}" for pb in pbs)) if pbs else ""


def actions(pbs: list[Playbook]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for pb in pbs:  # the best-ranked playbook wins on conflicts
        for k, v in pb.actions.items():
            out.setdefault(k, v)
    return out


def clean_noise(texts: list[str]) -> list[str]:
    """Copies of long tokens with non-base64 characters removed and '=' padding restored."""
    out = []
    for t in texts:
        for tok in re.findall(r"\S{16,}", str(t)):
            c = re.sub(r"[^A-Za-z0-9+/]", "", tok)
            if c != tok and len(c) >= 12:
                out.append(c + "=" * (-len(c) % 4))
    return out
