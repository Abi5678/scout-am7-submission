"""Typed decision layer ("Jev-style"): closed option sets -> calibrated probabilities.

Each decision presents enumerated options labelled A, B, C...; the model may only pick a label.
Probabilities come from logprobs over the label token when the proxy returns them, else from
k constrained samples (vote frequency, Laplace-smoothed). Output is always validated against the
option set, so the layer can never emit a tool, value or type outside it. The model distribution is
mixed with a deterministic prior so a silent/broken model degrades to the prior, never below it.
"""
from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass
from typing import Any, Callable

LABELS = "ABCDEFGH"
ChatFn = Callable[[list[dict[str, str]], dict[str, Any]], tuple[str, dict[str, Any]]]


@dataclass
class Decision:
    values: list[Any]
    probs: list[float]
    method: str  # logprobs|vote|prior
    tokens: int = 0

    @property
    def best(self) -> Any:
        return self.values[max(range(len(self.probs)), key=self.probs.__getitem__)]

    @property
    def confidence(self) -> float:
        return max(self.probs) if self.probs else 0.0

    @property
    def margin(self) -> float:
        p = sorted(self.probs, reverse=True)
        return p[0] - (p[1] if len(p) > 1 else 0.0)


def _norm(xs: list[float]) -> list[float]:
    z = sum(xs)
    return [x / z for x in xs] if z > 0 else [1 / len(xs)] * len(xs)


def parse_label(text: str, n: int) -> int | None:
    t = re.sub(r"<think>.*?</think>", "", text or "", flags=re.S | re.I).strip()
    try:
        obj = json.loads(t[t.index("{"): t.rindex("}") + 1])
        t = str(obj.get("choice", ""))
    except (ValueError, AttributeError):
        pass
    m = re.search(r"\b([A-H])\b", t.upper())
    if m and LABELS.index(m.group(1)) < n:
        return LABELS.index(m.group(1))
    return None


def label_logprobs(usage: dict[str, Any], n: int) -> list[float] | None:
    """Extract P(label) from OpenAI-style logprobs (first content token, top_logprobs)."""
    lp = usage.get("logprobs") or {}
    content = lp.get("content") if isinstance(lp, dict) else None
    if not content:
        return None
    # the label is rarely the first token ('{"choice": "B"}'): use the first position whose sampled
    # token is a bare label letter, and read the alternatives at that position
    first = next((c for c in content if str((c or {}).get("token") or "").strip().strip('"{:').upper()
                  in LABELS[:n] and len(str(c.get("token")).strip().strip('"{:')) == 1), None)
    if first is None:
        return None
    tops = first.get("top_logprobs") or [{"token": first.get("token"), "logprob": first.get("logprob")}]
    mass = [0.0] * n
    for t in tops:
        tok = str(t.get("token") or "").strip().strip('"{:').upper()
        if len(tok) == 1 and tok in LABELS[:n] and t.get("logprob") is not None:
            mass[LABELS.index(tok)] += math.exp(float(t["logprob"]))
    return _norm(mass) if sum(mass) > 0 else None


def decide(question: str, options: list[str], values: list[Any], prior: list[float], chat: ChatFn | None,
           *, k: int = 3, prior_weight: float = 0.5, use_logprobs: bool = True) -> Decision:
    n = len(options)
    assert n == len(values) == len(prior) and 0 < n <= len(LABELS)
    prior = _norm(list(prior))
    if chat is None or n == 1:
        return Decision(values, prior, "prior")
    body = (f"{question}\nOPTIONS:\n" + "\n".join(f"{LABELS[i]}) {o[:160]}" for i, o in enumerate(options))
            + f"\nReply with JSON only: {{\"choice\": \"<one of {','.join(LABELS[:n])}>\"}}")
    msgs = [{"role": "system", "content": "Pick exactly one option label. JSON only."},
            {"role": "user", "content": body}]
    tokens = 0
    model_p: list[float] | None = None
    method = "prior"
    try:
        try:
            params = {"temperature": 0.0, "max_tokens": 16}
            if use_logprobs:
                params.update({"logprobs": True, "top_logprobs": 5})
            text, usage = chat(msgs, params)
        except Exception:
            if not use_logprobs:
                raise
            text, usage = chat(msgs, {"temperature": 0.0, "max_tokens": 8})  # proxy rejected logprobs
        if True:
            tokens += int(usage.get("total_tokens") or 0)
            model_p = label_logprobs(usage, n)
            if model_p:
                method = "logprobs"
            else:  # no logprobs: count this greedy sample as the first vote
                i = parse_label(text, n)
                votes = [1.0 if j == i else 0.0 for j in range(n)]
                for _ in range(k - 1):
                    text, usage = chat(msgs, {"temperature": 0.7, "max_tokens": 16})
                    tokens += int(usage.get("total_tokens") or 0)
                    i = parse_label(text, n)
                    if i is not None:
                        votes[i] += 1
                if sum(votes):
                    model_p, method = _norm([v + 0.5 for v in votes]), "vote"
    except Exception:
        model_p = None
    if model_p is None:
        return Decision(values, prior, "prior", tokens)
    mixed = _norm([prior_weight * p + (1 - prior_weight) * q for p, q in zip(prior, model_p)])
    return Decision(values, mixed, method, tokens)


def ece(confs: list[float], correct: list[bool], bins: int = 10) -> float:
    """Expected calibration error."""
    if not confs:
        return float("nan")
    tot = 0.0
    for b in range(bins):
        lo, hi = b / bins, (b + 1) / bins
        idx = [i for i, c in enumerate(confs) if lo < c <= hi or (b == 0 and c == 0)]
        if idx:
            acc = sum(correct[i] for i in idx) / len(idx)
            conf = sum(confs[i] for i in idx) / len(idx)
            tot += len(idx) / len(confs) * abs(acc - conf)
    return tot
