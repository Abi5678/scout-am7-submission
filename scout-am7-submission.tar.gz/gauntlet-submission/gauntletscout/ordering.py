"""Deterministic check for plain-language ordering puzzles (Practice logic-puzzle family).

Parses clues like "X is immediately before Y", "X is somewhere to the left of Y", "X is not first or last",
"X is the final presenter" into position constraints over the entities named in a candidate answer, then
brute-forces permutations. Conservative: a clue it cannot read marks the parse as partial, and a parse
with zero solutions is discarded (the parser, not the puzzle, is wrong).
"""
from __future__ import annotations

import itertools
import re
from typing import Callable

ORD = {"first": 1, "1st": 1, "second": 2, "2nd": 2, "third": 3, "3rd": 3, "fourth": 4, "4th": 4,
       "fifth": 5, "5th": 5, "sixth": 6, "6th": 6, "seventh": 7, "7th": 7, "eighth": 8, "8th": 8}
LAST = ("last", "final")
NEG_RE = re.compile(r"\b(not|never|n't|isn't|doesn't|wasn't|didn't|cannot|can't)\b|n't\b", re.I)
REVERSED_RE = re.compile(r"right[- ]to[- ]left|latest to earliest|last to first|descending|bottom[- ]to[- ]top|"
                         r"reverse", re.I)
MAX_N = 8
Pos = dict  # entity -> 1-based position
Con = Callable[[Pos], bool]


def items(answer: str) -> list[str]:
    return [x.strip() for x in (answer or "").split(",") if x.strip()]


def key(name: str) -> str:
    return re.sub(r"^(team|the)\s+", "", " ".join(name.lower().split()))


def _mentions(clue: str, keys: list[str]) -> list[str]:
    hits = []
    for k in keys:
        m = re.search(r"(?<![\w])" + re.escape(k) + r"(?![\w])", clue, re.I)
        if m:
            hits.append((m.start(), k))
    return [k for _, k in sorted(hits)]


def _pair(rel: str, a: str, b: str, n: int) -> Con | None:
    imm = re.search(r"\b(immediately|directly|right|just)\s+(before|after|to the (left|right) of|ahead of|"
                    r"behind|preced|follow)", rel, re.I)
    before = re.search(r"\b(before|earlier than|to the left of|ahead of|preced\w*|in front of)\b", rel, re.I)
    after = re.search(r"\b(after|later than|to the right of|behind|follow\w*)\b", rel, re.I)
    if re.search(r"\b(next to|adjacent)\b", rel, re.I):
        return None if (before or after) else (lambda p: abs(p[a] - p[b]) == 1)
    if before and after:
        return None
    if imm and before:
        return lambda p: p[a] + 1 == p[b]
    if imm and after:
        return lambda p: p[a] == p[b] + 1
    if before:
        return lambda p: p[a] < p[b]
    if after:
        return lambda p: p[a] > p[b]
    return None


def _single(rel: str, a: str, n: int) -> tuple[list[int], bool] | None:
    """-> (positions mentioned, negated) or None."""
    low = rel.lower()
    pos = [v for w, v in ORD.items() if re.search(r"\b" + w + r"\b", low)]
    if any(re.search(r"\b" + w + r"\b", low) for w in LAST):
        pos.append(n)
    pos += [int(x) for x in re.findall(r"\b(?:position|place|spot|slot)\s+(\d+)\b", low) if 1 <= int(x) <= n]
    if re.search(r"\b(before|after|left|right|next|adjacent|between|than)\b", low):
        return None
    if not pos:
        return None
    return sorted(set(pos)), bool(NEG_RE.search(rel))


def parse(clues: list[str], answer: str, description: str = "") -> tuple[list[Con], bool, list[str]]:
    """-> (constraints, every clue parsed, entity keys in candidate order)."""
    ks = [key(x) for x in items(answer)]
    if len(ks) < 2 or len(set(ks)) != len(ks) or len(ks) > MAX_N or REVERSED_RE.search(description or ""):
        return [], False, ks
    n, cons, full = len(ks), [], True
    for clue in clues:
        c = str(clue)
        ents = _mentions(c, ks)
        con: Con | None = None
        if len(ents) == 2:
            a, b = ents
            con = _pair(c, a, b, n)
            if con is not None and NEG_RE.search(c):
                # negation must govern the relation ("X is not (immediately) before Y"), else unreadable
                rel_neg = re.search(NEG_RE.pattern + r"[\w\s]{0,30}?\b(before|after|left|right|ahead|behind|"
                                    r"preced|follow|next|adjacent|earlier|later|in front)", c, re.I)
                if rel_neg and len(NEG_RE.findall(c)) == 1 and not re.search(r"\b(but|and|or)\b", c, re.I):
                    f = con
                    con = (lambda f: lambda p: not f(p))(f)
                else:
                    con = None
        elif len(ents) == 1:
            got = _single(c, ents[0], n)
            if got:
                ps, neg = got
                a = ents[0]
                if neg:
                    con = (lambda a, ps: lambda p: p[a] not in ps)(a, ps)
                elif len(ps) == 1:
                    con = (lambda a, v: lambda p: p[a] == v)(a, ps[0])
        if con is None:
            full = False
        else:
            cons.append(con)
    return cons, full, ks


def solutions(cons: list[Con], ks: list[str], limit: int = 2) -> list[list[str]]:
    out = []
    for perm in itertools.permutations(ks):
        p = {k: i + 1 for i, k in enumerate(perm)}
        if all(c(p) for c in cons):
            out.append(list(perm))
            if len(out) >= limit:
                break
    return out


def satisfies(cons: list[Con], answer: str, ks: list[str]) -> bool:
    got = [key(x) for x in items(answer)]
    if sorted(got) != sorted(ks):
        return False
    p = {k: i + 1 for i, k in enumerate(got)}
    return all(c(p) for c in cons)


def reorder(answer: str, order: list[str]) -> str:
    """Candidate's own item spellings in the solved order, same separator style."""
    by = {key(x): x for x in items(answer)}
    sep = ", " if ", " in answer else ","
    return sep.join(by[k] for k in order)


def verdict(clues: list[str], answer: str, description: str = "") -> dict:
    """{'full', 'unique', 'ok' (candidate satisfies parsed clues), 'solution' (reordered answer or ''),
    'cons', 'ks'}; parse discarded (cons=[]) when it admits no solution."""
    cons, full, ks = parse(clues, answer, description)
    if not cons:
        return {"full": False, "unique": False, "ok": True, "solution": "", "cons": [], "ks": ks}
    sols = solutions(cons, ks)
    if not sols:
        return {"full": False, "unique": False, "ok": True, "solution": "", "cons": [], "ks": ks}
    unique = full and len(sols) == 1
    return {"full": full, "unique": unique, "ok": satisfies(cons, answer, ks),
            "solution": reorder(answer, sols[0]) if unique else "", "cons": cons, "ks": ks}


def bare_names(answer: str, description: str = "") -> str:
    """'Team Alpha, Team Bravo, ...' -> 'Alpha, Bravo, ...' when every item is '<Prefix> <Name>' with the same
    prefix and the task names that class ('Five teams present ...'). Practice 203/214/285/317: the prefixed form
    made the judge deliberate 13-43 s (317: no verdict, quality 0); bare names were judged in ~2-6 s."""
    parts = [x.strip() for x in (answer or "").split(",")]
    if len(parts) < 3 or any(not p for p in parts):
        return answer
    words = [p.split() for p in parts]
    pre = words[0][0]
    if any(len(w) != 2 or w[0] != pre for w in words) or not pre[:1].isupper():
        return answer
    if not re.search(rf"\b{re.escape(pre.lower())}s?\b", (description or "").lower()):
        return answer
    sep = ", " if ", " in answer else ","
    return sep.join(w[1] for w in words)
