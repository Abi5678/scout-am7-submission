"""Per-call LLM policy: adaptive timeout and thinking on/off.

Thinking is OFF by default (it cost 30s+ per call with no benefit on decodable puzzles). It is
turned on only when the puzzle is hard, the deterministic evidence is not already confident, and
there is enough time before the submit line. SCOUT_THINK=0|1|auto overrides (default auto).
"""
from __future__ import annotations

import os
from typing import Any

THINK_MIN_LINE_S = 40.0  # need this much time before the submit line to afford thinking
FLOOR_S, NOTHINK_CAP_S, THINK_CAP_S = 3.0, 25.0, 60.0


def want_thinking(difficulty: str, to_line_s: float, confident: bool) -> bool:
    mode = os.getenv("SCOUT_THINK", "auto").lower()
    if mode in ("0", "off", "false"):
        return False
    if mode in ("1", "on", "true"):
        return to_line_s > 2 * FLOOR_S
    return difficulty.lower() == "hard" and not confident and to_line_s >= THINK_MIN_LINE_S


def call_timeout(to_line_s: float, thinking: bool) -> float:
    """Spend at most ~half the time left before the submit line on one call (leaves room for a retry
    and the submit), bounded by a per-mode cap."""
    cap = THINK_CAP_S if thinking else NOTHINK_CAP_S
    return max(min(FLOOR_S, to_line_s), min(cap, 0.5 * to_line_s))


def thinking_params(thinking: bool, base: dict[str, Any]) -> dict[str, Any]:
    p = dict(base)
    p["reasoning_effort"] = "low" if thinking else "none"
    if thinking:
        p["max_tokens"] = max(int(p.get("max_tokens") or 0), 4096)
    return p
