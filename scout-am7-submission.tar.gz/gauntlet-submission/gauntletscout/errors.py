"""Classify tool/model failures: retry only what can succeed on retry."""
from __future__ import annotations

import re

TRANSIENT = re.compile(r"(timeout|timed out|transient|unavailable|temporar|rate.?limit|429|50[234]|"
                       r"connection|reset by peer|closedresource|broken pipe|try again|overloaded|busy)", re.I)
PERMANENT = re.compile(r"(wrong|invalid|locked|not found|no such|unknown (tool|handle|entry|key|slot|id)|denied|forbidden|401|403|"
                       r"validation|missing|unexpected|not_(text|image)_challenge|already submitted|409)", re.I)
TRANSPORT = re.compile(r"(closedresource|endofstream|brokenresource|connection|remoteprotocol|readerror|"
                       r"sse|anyio)", re.I)


def classify(err: str) -> str:
    """-> 'transient' | 'permanent' | 'transport' | 'unknown'."""
    e = str(err or "")
    if TRANSPORT.search(e) and not PERMANENT.search(e):
        return "transport"
    if PERMANENT.search(e):
        return "permanent"
    if TRANSIENT.search(e):
        return "transient"
    return "unknown"


def backoff(attempt: int, base: float = 0.2, cap: float = 2.0) -> float:
    return min(cap, base * (2 ** attempt))


NEGATIVE = re.compile(r"^\s*(no such|not found|empty|nothing|none|unknown entry|the oracle is silent|vault is empty|"
                      r"slot empty|no (entry|record|result)s?)\b", re.I)


def uninformative(res: dict) -> bool:
    """A non-error result that carries no evidence (e.g. 'no such entry'): keep trying other variants."""
    if any(isinstance(v, list) for v in res.values()) and not any(v for v in res.values() if isinstance(v, list)):
        return True  # {"results": [], "note": ...}: an empty search is no evidence
    vals = [v for k, v in res.items() if k not in ("agent_id",) and isinstance(v, str)]
    return bool(vals) and all(NEGATIVE.search(v) or not v.strip() for v in vals)
