"""GauntletScout: budgeted LangGraph agent for the NVIDIA Live Agent Gauntlet."""
__version__ = "0.1.0"
