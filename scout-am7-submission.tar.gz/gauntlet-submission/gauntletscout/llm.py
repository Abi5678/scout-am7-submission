"""OpenAI-compatible calls through the organizer /proxy (mock: local stub or forwarded upstream).

Handles: multimodal messages (image_url parts), native tool calls, logprobs, reasoning models
(content may be empty with the answer only in `reasoning`/`reasoning_content`, or wrapped in
<think>), and proxies that reject optional params (400 -> caller drops the param and retries).
"""
from __future__ import annotations

import re
from typing import Any

import requests

from arena_clients.config import get_arena_api_key, get_proxy_host
from arena_clients.proxy_headers import build_proxy_headers

ANSWER_RE = re.compile(r"^\s*\**ANSWER\**:\s*(.+?)\s*$", re.M | re.I)
THINK_RE = re.compile(r"<think>.*?(</think>|$)", re.S | re.I)
OPTIONAL_PARAMS = ("reasoning_effort", "logprobs", "top_logprobs", "tools", "tool_choice", "response_format", "seed")


class LLMHTTPError(Exception):
    def __init__(self, status: int, text: str) -> None:
        super().__init__(f"HTTP {status}: {text[:200]}")
        self.status, self.text = status, text

    def rejected_param(self, params: dict[str, Any]) -> str | None:
        """Which optional param the proxy complained about (400/422), if identifiable."""
        if self.status not in (400, 422):
            return None
        low = self.text.lower()
        for p in OPTIONAL_PARAMS:
            if p in params and p in low:
                return p
        for p in OPTIONAL_PARAMS:  # unspecific 400: drop the most exotic param first
            if p in params:
                return p
        return None


def chat(model: str, messages: list[dict[str, Any]], params: dict[str, Any], agent_id: str,
         usage_scope: str | None, timeout_s: float, session: Any = None) -> tuple[str, dict[str, Any]]:
    url = f"{get_proxy_host().rstrip('/')}/chat/completions"
    headers = {"Authorization": f"Bearer {get_arena_api_key()}", "Content-Type": "application/json"}
    headers.update(build_proxy_headers(agent_id=agent_id, usage_scope=usage_scope))
    body = {"model": model, "messages": messages, **params}
    r = (session or requests).post(url, json=body, headers=headers, timeout=timeout_s)
    if r.status_code >= 400:
        raise LLMHTTPError(r.status_code, r.text)
    data = r.json()
    choice = (data.get("choices") or [{}])[0]
    msg = choice.get("message") or {}
    text = str(msg.get("content") or "")
    reasoning = str(msg.get("reasoning_content") or msg.get("reasoning") or "")
    usage = dict(data.get("usage") or {})
    usage["finish_reason"] = choice.get("finish_reason")
    usage["reasoning"] = reasoning
    if msg.get("tool_calls"):
        usage["tool_calls"] = msg["tool_calls"]
    if choice.get("logprobs"):
        usage["logprobs"] = choice["logprobs"]
    if not THINK_RE.sub("", text).strip() and reasoning:
        # reasoning model ran out of budget / put everything in the reasoning channel:
        # salvage an explicit ANSWER line from it (never the raw chain of thought)
        m = list(ANSWER_RE.finditer(reasoning))
        text = f"ANSWER: {m[-1].group(1)}" if m else ""
    return text, usage


def extract_answer(text: str) -> str:
    text = THINK_RE.sub("", text or "")
    m = ANSWER_RE.search(text)
    if m:
        return m.group(1).strip().strip('"*').strip()
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    return lines[0] if lines else ""
