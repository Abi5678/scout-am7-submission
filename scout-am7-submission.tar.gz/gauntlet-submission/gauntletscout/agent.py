"""GauntletScout runtime: a budgeted LangGraph state machine.

boot -> discover -> triage -> {text: explore<->decode -> solve | image: image_solve} -> verify -> submit

Env only (no .env needed): ARENA_SERVER, ARENA_API_KEY, AGENT_ID [, ARENA_USAGE_SCOPE].
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import os
import re
import sys
import time
from pathlib import Path
from typing import Any, TypedDict

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from langgraph.graph import END, StateGraph  # noqa: E402

from arena_clients.http_client import ArenaAPIError, ArenaConnectionError, HttpArenaClient  # noqa: E402
from arena_clients.mcp_client import McpArenaClient  # noqa: E402
from base_strategy import ChallengeContext  # noqa: E402
from model_selector import fetch_available_models  # noqa: E402
from my_strategy import MyStrategy  # noqa: E402

from gauntletscout import codec, errors, llm, llmpolicy, numeric, ordering, schema, skills  # noqa: E402
from gauntletscout.decide import decide  # noqa: E402
from gauntletscout.errors import uninformative as errors_mod_uninformative  # noqa: E402
from gauntletscout.hypothesis import Hypotheses, format_for_rules, looks_like_junk, provenance_delta, validate_answer  # noqa: E402
from gauntletscout.discovery import Evidence, ToolInfo, build_args, index_tools, validate_args  # noqa: E402
from gauntletscout.governor import Governor  # noqa: E402

RAW_ERROR_RE = re.compile(r"^\s*(error|unknown tool|output validation error|traceback|exception|transient)", re.I)
MCP_CALL_CAP_S = 10.0
CLUE_REFETCH_WAIT_S = 1.0
PROBE_CALL_CAP_S = 4.0  # optional (non-required) probes: a hung exploratory tool cost 10-20s/heat in chaos/holdout
IMAGE_CALL_CAP_S = 60.0  # Practice image_generate/edit took 10-20s; a 10s cap timed out and re-generated
LLM_CALL_CAP_S = 30.0  # legacy ceiling; per-call timeouts come from llmpolicy
LOBBY_RE = re.compile(r"locked|waiting for (the )?organi[sz]er|not (yet )?started|lobby|battle has not|not active", re.I)
LOBBY_POLL_S = float(os.getenv("SCOUT_LOBBY_POLL_S", "1.0"))
GO_GRACE_S = float(os.getenv("SCOUT_GO_GRACE_S", "20"))


class LobbyTimeout(Exception):
    """Organizer GO never came within SCOUT_LOBBY_WAIT_S: exit without an (unscorable) emergency submit."""
RACE_N = int(os.getenv("SCOUT_RACE_N", "3"))  # 5 burned tokens/budget on losers; 3 kept the win rate
LOGIC_RE = re.compile(r"\b(infer|deduce|determine) (the|which|who|each)\b", re.I)
DATA_URI_RE = re.compile(r"data:image/[a-z]+;base64,[A-Za-z0-9+/=]+")


def log(msg: str) -> None:
    print(f"[scout {time.strftime('%H:%M:%S')}] {msg}", flush=True)


def _strings(obj: Any, depth: int = 0) -> list[str]:
    """Flatten string leaves of a tool result (so decoders see payloads, not JSON quoting)."""
    if depth > 4:
        return []
    if isinstance(obj, str):
        return [obj] if obj.strip() else []
    if isinstance(obj, dict):
        return [s for v in obj.values() for s in _strings(v, depth + 1)]
    if isinstance(obj, list):
        return [s for v in obj for s in _strings(v, depth + 1)]
    return []


def arbitration_clues(clues: list[str]) -> list[str]:
    """Plain-language clues only for the arbiter. Ciphertext (even short-token rot/atbash, which the old
    20-char-token filter let through) made the model start decoding and blow its 80-token budget or invent
    a decode ('ykhf Kxrdctobd' -> 'Reykjavik is genuine'); the decoded options already carry that text."""
    cipherish = re.compile(r"[^\s]{20,}")
    out = []
    for c in clues:
        if cipherish.search(c) or DATA_URI_RE.search(c):
            continue
        best = codec.decode_all([c[:300]], top=1)
        if best and best[0].score > codec.english_score(c) + 1.0:
            continue  # decodes to better English than it reads: it's an intercept, not evidence
        out.append(c)
    return out


class State(TypedDict, total=False):
    modality: str
    answer: str
    image_uri: str
    rounds: int
    result: dict[str, Any]
    error: str


class Scout:
    def __init__(self) -> None:
        self.strategy = MyStrategy()
        self.agent_id = (os.getenv("AGENT_ID") or self.strategy.agent_id).strip()
        self.http = HttpArenaClient()
        self.mcp: McpArenaClient | None = None
        self.tools: dict[str, ToolInfo] = {}
        self.memory: dict[str, Any] = {"calls": {}, "texts": [], "decoded": [], "probes": 0}
        self.ev = Evidence()
        self.gov: Governor | None = None
        self.ctx = ChallengeContext(challenge_type="text")
        self.challenge: dict[str, Any] = {}
        self.usage_scope = os.getenv("ARENA_USAGE_SCOPE") or None
        self.tokens = 0
        self.model = ""
        self.thoughts = 0
        self.submitted = False
        self.submitting = False
        self.hyps = Hypotheses()
        self.best_answer = ""
        self.best_image = ""
        self.decision_log: list[dict[str, Any]] = []
        self.use_decide = os.getenv("SCOUT_DECIDE", "0") == "1"
        self.reconnects = 0
        self.unsupported: set[str] = set()  # optional LLM params the proxy rejected
        self.llm_log: list[dict[str, Any]] = []
        self.library = skills.load()  # frozen playbooks shipped in the package (read-only, no network)
        self.playbooks: list[skills.Playbook] = []
        self.act: dict[str, Any] = {}
        self.raw_case: dict[str, str] = {}
        self.logic_answer = ""

    # ------------------------------------------------------------ helpers
    def think(self, text: str) -> None:
        """Post a spectator thought (text: REST; image flow additionally via MCP in image node)."""
        try:
            if self.http.broadcast_thought(self.agent_id, text[:280]):
                self.thoughts += 1
        except (ArenaAPIError, ArenaConnectionError) as e:
            log(f"thought failed: {e}")

    async def call(self, name: str, args: dict[str, Any], *, retries: int = 1,
                   cap: float | None = None, fresh: bool = False) -> dict[str, Any] | None:
        """Guarded MCP call: only discovered names, schema-checked args, time-boxed, memoised.

        cap: per-attempt timeout override for optional probes; a probe that times out is not retried."""
        info = self.tools.get(name)
        if info is None:
            log(f"refused unknown tool {name!r}")
            return None
        if "agent_id" in info.properties and "agent_id" not in args:
            args = {**args, "agent_id": self.agent_id}
        args = schema.coerce_args(info.schema, args)
        err = validate_args(info, args) or (schema.check(args, info.schema) if info.schema.get("properties") else None)
        if err:
            log(f"refused {name}: {err}")
            return None
        key = (name, hashlib.sha1(json.dumps(args, sort_keys=True, default=str).encode()).hexdigest()[:12])
        prev = self.memory["calls"].get(key)
        if prev is not None and not fresh and ("error" not in prev or errors.classify(str(prev.get("error"))) == "permanent"
                                 and "locked" not in str(prev.get("error")).lower()):
            return prev  # identical call already succeeded, or failed for a reason a retry cannot fix
        assert self.mcp is not None
        for attempt in range(retries + 1):
            c = cap if cap is not None else IMAGE_CALL_CAP_S if name.startswith("image_") else MCP_CALL_CAP_S
            budget = self.gov.budget(c) if self.gov else c
            try:
                res = await asyncio.wait_for(self.mcp.call_tool(name, args), timeout=budget)
            except asyncio.TimeoutError:
                log(f"{name} timed out after {budget:.1f}s")
                res = {"error": "timeout"}
            except Exception as e:  # transport / tool error
                res = {"error": f"{type(e).__name__}: {e}"}
                if errors.classify(res["error"]) == "transport":
                    await self._connect(reason=res["error"])
            if set(res) == {"raw"} and RAW_ERROR_RE.search(str(res["raw"])):
                res = {"error": str(res["raw"])[:300]}  # isError results arrive as bare text
            self.memory["calls"][key] = res
            if "error" in res and os.getenv("SCOUT_DEBUG"):
                log(f"{name}({ {k: v for k, v in args.items() if k != 'agent_id'} }) error: {str(res)[:160]}")
            if "error" not in res:
                self.strategy.on_tool_result(name, res, self.ctx)
                self.ev.absorb_result(res)
                for v in _strings(res):
                    self._absorb(v)
                return res
            if self.gov and self.gov.must_submit():
                break
            kind = errors.classify(str(res.get("error")))
            if re.search(r"\bno (archive|such tool|vault|registry)|not (available|applicable) for this", str(res.get("error")), re.I):
                info.dead = True  # tool irrelevant to this challenge: stop probing it
            if kind == "permanent" or (cap is not None and res.get("error") == "timeout"):
                break  # retrying a wrong code / bad arg cannot help and costs time
            if attempt < retries:
                await asyncio.sleep(errors.backoff(attempt))
        return res

    async def _connect(self, reason: str = "") -> None:
        """(Re)open the MCP SSE session with exponential backoff. Old session is abandoned, not awaited."""
        for attempt in range(4):
            try:
                m = McpArenaClient()
                await asyncio.wait_for(m.__aenter__(), timeout=5.0)
                self.mcp = m
                if reason:
                    self.reconnects += 1
                    log(f"mcp reconnected ({reason[:60]})")
                return
            except Exception as e:
                log(f"mcp connect failed ({type(e).__name__}); retry")
                if self.gov and self.gov.must_submit():
                    return
                await asyncio.sleep(errors.backoff(attempt, 0.3, 2.0))

    def _retrieve_skills(self, n_clues: int | None = None) -> None:
        feat = skills.features(self.ctx.description, self.ctx.rules, self.ctx.clues, self.ctx.required_tools, n_clues)
        self.playbooks = skills.retrieve(self.library, feat)
        self.act = skills.actions(self.playbooks)
        if self.playbooks:
            log(f"skills: {[pb.id for pb in self.playbooks]} actions={self.act}")

    def _absorb(self, text: str) -> None:
        self.memory["texts"].append(text)
        self.ev.absorb(text)

    # ------------------------------------------------------------ nodes
    async def boot(self, state: State) -> State:
        self.in_lobby = True  # register can block in the lobby: the watchdog must not fire
        try:
            self.http.register(self.agent_id, self.strategy.agent_name)
        finally:
            self.in_lobby = False
        self.think("GauntletScout online: discovering tools.")
        if not self.usage_scope:
            self.usage_scope = self.http.fetch_usage_scope()
        return state

    async def discover(self, state: State) -> State:
        assert self.mcp is not None
        self.tools = index_tools(await self.mcp.list_tool_defs())
        modality = McpArenaClient.detect_modality(list(self.tools), agent_id=self.agent_id)
        kinds: dict[str, int] = {}
        for t in self.tools.values():
            kinds[t.kind] = kinds.get(t.kind, 0) + 1
        log(f"{len(self.tools)} tools {kinds}; modality={modality}")
        return {**state, "modality": modality, "rounds": 0}

    def _phase(self) -> str:
        """Competition phase from REST ('' when unreadable)."""
        http = getattr(self, "http", None)
        for fn in ("get_competition", "health"):
            try:
                d = getattr(http, fn)() or {}
            except Exception:
                continue
            ph = str(d.get("phase") or d.get("status") or (d.get("competition") or {}).get("phase") or "").lower()
            if ph:
                return ph
        return ""

    def _refresh_scope(self) -> None:
        try:
            scope = self.http.fetch_usage_scope()
        except Exception:
            scope = None
        if scope:
            self.usage_scope = scope

    async def wait_for_running(self, limit: float) -> bool:
        """Kit-style lobby wait: poll the REST phase until 'running'. False = phase unreadable/never running."""
        start, seen = time.monotonic(), False
        while time.monotonic() - start <= limit:
            ph = self._phase()
            if ph:
                seen = True
                if not re.search(r"lobby|wait|pending|registr|not.?started|scheduled|idle|paused", ph):
                    return True  # running (or practice/other non-lobby phase): go
                if not getattr(self, "_lobby_logged", False):
                    log(f"lobby (phase={ph}); waiting for organizer GO")
                    self._lobby_logged = True
            elif not seen and time.monotonic() - start > 3 * LOBBY_POLL_S:
                return False  # phase not exposed: fall back to probing get_challenge
            await asyncio.sleep(LOBBY_POLL_S)
        if seen:
            raise LobbyTimeout("phase never reached running")
        return False

    async def _await_go(self, name: str) -> dict[str, Any] | None:
        """Live event: after registration the challenge stays locked until the organizer's GO.
        Wait on the REST phase, then fetch fresh with a short GO grace; fall back to probing.
        Raises LobbyTimeout after SCOUT_LOBBY_WAIT_S (no time budget yet, watchdog paused)."""
        limit = float(os.getenv("SCOUT_LOBBY_WAIT_S", "3600"))
        start = time.monotonic()
        self.in_lobby = True
        try:
            waited = False
            try:
                waited = await self.wait_for_running(limit)
            except LobbyTimeout:
                raise
            except Exception as e:
                log(f"phase wait failed ({type(e).__name__}); probing")
            if waited:
                self._refresh_scope()  # lobby scope can change at GO
                if time.monotonic() - start > 5:
                    await self._connect(reason="stale after lobby")
            deadline = (time.monotonic() + GO_GRACE_S) if waited else (start + limit)
            locked_seen = False
            while True:
                data = await self.call(name, {}, retries=0, fresh=True)
                if not (data and "error" in data and LOBBY_RE.search(str(data.get("error")))):
                    if locked_seen:
                        self._refresh_scope()
                    return data
                locked_seen = True
                if time.monotonic() > deadline:
                    if waited:
                        log("GO grace elapsed; still locked")
                        return data
                    raise LobbyTimeout("lobby wait limit reached")
                if not getattr(self, "_lobby_logged", False):
                    log("lobby open; waiting for organizer GO")
                    self._lobby_logged = True
                await asyncio.sleep(LOBBY_POLL_S)
        finally:
            self.in_lobby = False
            self._t0 = time.monotonic()

    async def triage(self, state: State) -> State:
        image = state["modality"] == "image"
        name = "arena.image.get_challenge" if image else "arena.get_challenge"
        data = await self._await_go(name)
        for _ in range(4):
            if data and "error" not in data:
                break
            data = await self.call(name, {}, retries=0)
            if data and "error" not in data:
                break
            if data and data.get("code") in ("not_image_challenge", "not_text_challenge"):
                image = not image
                name = "arena.image.get_challenge" if image else "arena.get_challenge"
            await asyncio.sleep(0.3)
        data = data or {}
        self.challenge = data
        self.gov = Governor.start(data.get("max_time_s") or 60, data.get("time_remaining_s"),
                                  explore_frac=min(self.strategy.explore_until, float(os.getenv("SCOUT_SUBMIT_BY", "1"))),
                                  submit_frac=min(self.strategy.submit_by, float(os.getenv("SCOUT_SUBMIT_BY", "1"))))
        try:
            models = fetch_available_models()
        except Exception:
            models = []
        self.ctx = ChallengeContext(
            challenge_type="image" if image else "text",
            difficulty=str(data.get("difficulty") or "unknown"),
            challenge_text=str(data.get("description") or ""),
            description=str(data.get("description") or ""),
            rules=str(data.get("rules") or "") if not image else
            f"{data.get('prompt') or data.get('edit_prompt') or ''}\nNotes: {data.get('reference_notes') or ''}",
            clues=[str(c) for c in (data.get("clues") or [])],
            max_time_s=int(data.get("max_time_s") or 60),
            time_remaining_s=float(data.get("time_remaining_s") or data.get("max_time_s") or 60),
            available_models=models,
            tools_used=list(self.ctx.tools_used),
            required_tools=[str(t) for t in (data.get("required_tools") or [])],
            image_url=(data.get("input_image_uri") or None) if image else None,
        )
        self._absorb(json.dumps(data, default=str))
        missing_tools = [t for t in self.ctx.required_tools if t not in self.tools]
        if missing_tools:
            log(f"required tools not advertised: {missing_tools}")
        if not image and "arena.clues.list" in self.tools:
            lst = await self.call("arena.clues.list", {}, retries=3)
            ids = (lst or {}).get("clue_ids") or []
            self._retrieve_skills(n_clues=len(ids))  # pre-clue pass: a playbook may raise max_clues
            cap = int(self.act.get("max_clues") or 32)  # long logs hide the real clue past #10 (longctx)
            got = await self._fetch_clues([str(i) for i in ids[:cap]])
            self.ctx.clues += [str(g.get("text")) for g in got if g and g.get("text")]
        self._retrieve_skills()
        log(f"challenge {data.get('puzzle_id')} type={self.ctx.challenge_type} T={self.ctx.max_time_s}s "
            f"required={self.ctx.required_tools} clues={len(self.ctx.clues)}")
        return {**state, "modality": "image" if image else "text"}

    async def _fetch_clues(self, ids: list[str]) -> list[dict[str, Any] | None]:
        """Fetch clues concurrently; re-fetch ones lost to a burst of transient faults while time allows.
        Chaos 10-27: clue_0 (the ciphertext) failed 4x in a row and 'NOITPCIRSED' was submitted with 95 s left."""
        got = list(await asyncio.gather(*(self.call("arena.clues.get", {"clue_id": i}, retries=3) for i in ids)))
        for _ in range(2):
            miss = [k for k, g in enumerate(got) if not (g and g.get("text"))]
            if not miss or (self.gov and not self.gov.can_explore()):
                break
            await asyncio.sleep(CLUE_REFETCH_WAIT_S)
            again = await asyncio.gather(*(self.call("arena.clues.get", {"clue_id": ids[k]}, retries=2) for k in miss))
            for k, g in zip(miss, again):
                got[k] = g
        return got

    def _decode(self) -> list[str]:
        # never decode negative/empty tool replies: reversed 'no such entry' became a submitted answer
        texts = list(self.ctx.clues) + [t for t in self.memory["texts"][1:]
                                        if not errors_mod_uninformative({"text": t})]
        if self.act.get("clean_noise"):
            texts += skills.clean_noise(list(self.ctx.clues))
        budget = self.gov.budget(3.0) if self.gov else 3.0
        cands = codec.decode_all_safe(texts, top=10, timeout_s=min(3.0, budget))
        self.memory["decoded"] = cands
        for c in cands[:3]:
            self.ev.absorb(c.text)
        nums = [c for c in cands if c.text.strip().isdigit() or re.search(r"\b(code|pin)\b", c.text, re.I)]
        ranked_nums: list[str] = []
        for c in sorted(nums, key=codec.numeric_rank):
            for n in re.findall(r"\b\d{3,8}\b", c.text):
                if n not in ranked_nums:
                    ranked_nums.append(n)
        if ranked_nums:  # best numeric decode last (= tried first by build_args)
            self.ev.numbers = [n for n in self.ev.numbers if n not in ranked_nums] + ranked_nums[::-1]
        for c in cands:
            self.hyps.absorb_text(c.text, min(c.score, 12.0) / 4, f"decode:{c.method}")
        # provenance labels ('HQ [signature: INVALID] intercept (b64): ...') sit outside the ciphertext, so
        # decodes lose them: re-decode each labelled clue alone and shift the claims it yields
        for clue in self.ctx.clues[:8]:
            delta = provenance_delta(clue)
            if delta:
                for c in codec.decode_all_safe([clue], top=3, timeout_s=min(1.0, budget)):
                    self.hyps.adjust_claims(c.text, delta)
        self._update_best()
        return [c.text for c in cands]

    async def explore(self, state: State) -> State:
        """Decode, then probe required + unknown tools with evidence-derived args (budget-gated)."""
        self._decode()
        rounds = state.get("rounds", 0) + 1
        assert self.gov is not None
        order = self.strategy.plan_tools(self.ctx, list(self.tools))
        targets = [n for n in order if n in self.ctx.required_tools and n not in self.ctx.tools_used]
        if self.gov.can_explore():
            targets += [n for n in order if self.tools[n].kind == "unknown" and not self.tools[n].denied
                        and n not in targets]
        progressed = False
        errors = 0
        for name in targets:
            required = name in self.ctx.required_tools
            if not required and (self.memory["probes"] >= self.strategy.max_probe_calls or not self.gov.can_explore()):
                continue
            for args in build_args(self.tools[name], self.agent_id, self.ev, hint="key"):
                if getattr(self.tools[name], "dead", False) and not required:
                    break
                before = len(self.memory["calls"])
                if not required:
                    self.memory["probes"] += 1
                res = await self.call(name, args, retries=int(self.act.get("tool_retries", 3)) if required else 1,
                                      cap=None if required else PROBE_CALL_CAP_S)
                if res and "error" not in res:
                    progressed = progressed or len(self.memory["calls"]) > before
                    if not errors_mod_uninformative(res):
                        break  # one informative variant per tool is enough
                elif res and "error" in res:
                    errors += 1
            if required and name not in self.ctx.tools_used and not getattr(self.tools[name], "dead", False) \
                    and [r for r in self.tools[name].required if r != "agent_id"]:
                if await self._model_args(name):
                    progressed = True
        if progressed:
            self.think(f"Explored tools (round {rounds}); decoding evidence.")
        return {**state, "rounds": rounds, "error": "" if (progressed or errors) else "stalled"}

    def _explore_more(self, state: State) -> str:
        assert self.gov is not None
        if state.get("error") == "stalled" or state.get("rounds", 0) >= self.strategy.max_explore_rounds:
            return "solve"
        return "explore" if self.gov.can_explore() else "solve"

    def _update_best(self) -> None:
        for h in self.hyps.ranked():
            if not validate_answer(h.answer, self.ctx.rules) and not looks_like_junk(h.answer):
                self.best_answer = h.answer
                return
        for c in (self.memory.get("decoded") or [])[:5]:  # gated: first decode that reads like an answer
            guess = self.strategy.normalize_answer(c.text, self.ctx)
            if guess and not validate_answer(guess, self.ctx.rules) and not looks_like_junk(guess):
                self.best_answer = self.best_answer or guess
                return

    def _to_line(self) -> float:
        assert self.gov is not None
        return self.gov.max_time_s * self.gov.submit_frac - self.gov.elapsed()

    def _llm(self, msgs: list[dict[str, Any]], params: dict[str, Any], *, think: bool = False,
             purpose: str = "solve") -> tuple[str, dict[str, Any]]:
        """One proxy call with adaptive timeout, thinking policy and graceful param fallback (sync)."""
        p = llmpolicy.thinking_params(think, params)
        for _ in range(4):
            p = {k: v for k, v in p.items() if k not in self.unsupported}
            to_line = self._to_line()
            if to_line < 1.0:
                raise TimeoutError("no time left for an LLM call")
            timeout = llmpolicy.call_timeout(to_line, think)
            t0 = time.monotonic()
            try:
                text, usage = llm.chat(self.model, msgs, p, self.agent_id, self.usage_scope, timeout)
            except llm.LLMHTTPError as e:
                bad = e.rejected_param(p)
                if not bad:
                    raise
                log(f"proxy rejected {bad!r}; retrying without it")
                self.unsupported.add(bad)
                if bad == "tools":
                    self.unsupported.add("tool_choice")
                continue
            self.tokens += int(usage.get("total_tokens") or 0)
            self.llm_log.append({"purpose": purpose, "think": think, "s": round(time.monotonic() - t0, 2),
                                 "timeout": round(timeout, 1), "tokens": usage.get("total_tokens"),
                                 "finish": usage.get("finish_reason")})
            return text, usage
        raise RuntimeError("LLM call failed after dropping optional params")

    def _chat_fn(self):
        def chat(msgs, params):
            return self._llm(msgs, params, purpose="decide")
        return chat

    def _tool_texts(self) -> list[str]:
        """Short plaintext strings returned by successful tool calls (excluding clue/challenge echoes)."""
        clues = set(self.ctx.clues)
        out = []
        for (name, _), res in self.memory["calls"].items():
            if not res or "error" in res or name.startswith("arena.") or errors_mod_uninformative(res):
                continue
            out += [v for v in _strings(res) if v not in clues and len(v) < 600 and not v.startswith("data:")]
        return out[-8:]

    async def _arbitrate(self, hyps: list[Any]) -> bool:
        """Conflicting clean decodes ('from Oslo: ... X' vs 'from Cairo: ... Y'): ask one short, focused
        question (state the deciding fact in one sentence, then a letter) instead of an open-ended solve.
        Without thinking the model botched the combined task (~62% on 40 seeds); decomposed it got 40/40."""
        labels: list[tuple[str, Any]] = []
        for h in hyps:
            for c in self.memory.get("decoded") or []:
                m = re.search(r"(?:^|[.;]\s*)([^.;:]{2,60}?)\s*:?\s*the\s+pass\s*phrase\s+is\s+" + re.escape(h.answer),
                              c.text, re.I)
                if m and m.group(1).strip().lower() not in ("", "note", "the"):
                    labels.append((m.group(1).strip(), h))
                    break
        if len(labels) != len(hyps) or len({lab for lab, _ in labels}) != len(labels):
            return False
        arb = arbitration_clues(self.ctx.clues)
        if not arb:
            return False
        q = ("CLUES:\n" + "\n".join(f"- {c[:300]}" for c in arb[:6]) + "\nOPTIONS:\n"
             + "\n".join(f"{'ABCD'[i]}) message {lab}" for i, (lab, _) in enumerate(labels))
             + "\nFirst state the one fact needed (one short sentence), then a final line 'ANSWER: <letter>'.")
        if self.playbooks:
            q = skills.render(self.playbooks) + "\n" + q
        self.model = self.model or self._pick_model()
        try:
            text, _ = await asyncio.to_thread(self._llm, [{"role": "user", "content": q}],
                                              {"temperature": 0.0, "max_tokens": 80}, purpose="arbitrate")
        except Exception as e:
            log(f"arbitration failed: {type(e).__name__}: {e}")
            return False
        m = re.search(r"ANSWER:\s*\**\s*([A-D])\b", text or "")
        if not m or "ABCD".index(m.group(1)) >= len(labels):
            return False
        lab, h = labels["ABCD".index(m.group(1))]
        top = max(x.score for x in hyps)
        self.hyps.add(h.answer, top + 1.0, "arbiter")
        log(f"arbiter picked '{lab}' -> {h.answer}")
        self.think(f"Conflicting intercepts; the clues select the one {lab}.")
        return True

    def _decide_question(self) -> str:
        """Decision prompt WITH the evidence: without clues the model cannot arbitrate (it voted ~randomly
        and the decoder prior won, e.g. ignoring 'only the southern city is genuine')."""
        clues = "\n".join(f"- {DATA_URI_RE.sub('[image]', c)[:300]}" for c in self.ctx.clues[:8])
        dec = "\n".join(f"- {c.text[:200]}" for c in (self.memory.get("decoded") or [])[:4])
        tools = "\n".join(f"- {t[:200]}" for t in self._tool_texts())
        return (f"TASK: {self.ctx.description}\nRULES: {self.ctx.rules}\nCLUES:\n{clues}\n"
                + (f"DECODED:\n{dec}\n" if dec else "") + (f"TOOL RESULTS:\n{tools}\n" if tools else "")
                + "Using the clues, which is the correct answer?")

    def _images(self) -> list[str]:
        """Image data URIs seen in clues / tool results of a text challenge (max 2)."""
        out: list[str] = []
        for t in list(self.ctx.clues) + self.memory["texts"]:
            for u in DATA_URI_RE.findall(t):
                if u not in out and len(u) > 100:
                    out.append(u)
        return out[:2]

    def _vision_args(self, name: str) -> dict[str, Any]:
        """image_analyze's server default model may be off-roster (Practice: nemotron-nano-12b-vl -> HTTP 400);
        pass a roster vision-capable chat model when the tool takes a `model` arg."""
        info = self.tools.get(name)
        if not info or "model" not in info.properties:
            return {}
        m = self.strategy.pick_vision_model(self.ctx.available_models)
        return {"model": m} if m else {}

    def _image_model_args(self, name: str) -> dict[str, Any]:
        info = self.tools.get(name)
        if not info or "model" not in info.properties:
            return {}
        m = self.strategy.pick_image_model(self.ctx.available_models)
        return {"model": m} if m else {}

    def _is_logic(self) -> bool:
        """Plain-language constraint puzzle (Practice 'logic-puzzle'): deduce, don't decode."""
        kind = str(self.challenge.get("challenge_type") or "").lower()
        return "logic" in kind or bool(LOGIC_RE.search(self.ctx.description or ""))

    def _pick_model(self, need_image: bool = False) -> str:
        self.ctx.time_remaining_s = self.gov.remaining() if self.gov else self.ctx.time_remaining_s
        if need_image:
            imgs = self.strategy.prefer_image_models(self.ctx.available_models)
            if imgs:
                return imgs[0]
        models = self.strategy.rank_models(self.ctx, self.ctx.available_models)
        if self._is_logic():
            models = self.strategy.rank_strong(models)
        return models[0] if models else ""

    async def _model_args(self, name: str) -> bool:
        """Ask the model to fill a tool's arguments from the clues (native tool call, JSON fallback).

        Used when evidence-derived args failed for a required tool (e.g. a handle described in prose).
        Returns True once a call succeeds.
        """
        info = self.tools[name]
        if not self.ctx.available_models or not self.gov or self.gov.must_submit():
            return False
        self.model = self.model or self._pick_model()
        params_schema = json.loads(json.dumps(info.schema or {"type": "object", "properties": {}}))
        params_schema.get("properties", {}).pop("agent_id", None)
        if "required" in params_schema:
            params_schema["required"] = [r for r in params_schema["required"] if r != "agent_id"]
        fn = re.sub(r"[^A-Za-z0-9_-]", "_", name)[:64]
        tried: list[str] = []
        for attempt in range(2):
            if self.gov.must_submit():
                break
            clues = "\n".join(f"- {DATA_URI_RE.sub('[image]', c)[:300]}" for c in self.ctx.clues[:8])
            ask = (f"TASK: {self.ctx.description}\nCLUES:\n{clues}\n\nCall the tool `{name}` "
                   f"({info.description}) with the argument values the clues point to. Work out any "
                   f"riddle in the clues first. Use the exact format the clue asks for.")
            if self.playbooks:
                ask += "\n" + skills.render(self.playbooks)
            if tried:
                ask += "\nThese values were rejected: " + "; ".join(tried) + ". Try a different value."
            msgs = [{"role": "system", "content": "You fill tool arguments precisely. Prefer a tool call; "
                     "otherwise reply with JSON only: {\"arguments\": {...}}."},
                    {"role": "user", "content": ask}]
            params: dict[str, Any] = {"temperature": 0.0, "max_tokens": 300,
                                      "tools": [{"type": "function", "function": {
                                          "name": fn, "description": info.description[:300],
                                          "parameters": params_schema}}],
                                      "tool_choice": "auto"}
            try:
                text, usage = await asyncio.to_thread(self._llm, msgs, params, purpose="tool_args")
            except Exception as e:
                log(f"tool-arg proposal failed: {e}")
                return False
            args: dict[str, Any] | None = None
            for tc in usage.get("tool_calls") or []:
                raw = ((tc or {}).get("function") or {}).get("arguments")
                try:
                    args = json.loads(raw) if isinstance(raw, str) else dict(raw or {})
                    break
                except (ValueError, TypeError):
                    continue
            if args is None:
                m = re.search(r"\{.*\}", llm.THINK_RE.sub("", text or ""), re.S)
                try:
                    obj = json.loads(m.group(0)) if m else {}
                    args = obj.get("arguments", obj) if isinstance(obj, dict) else None
                except ValueError:
                    args = None
            if not isinstance(args, dict) or not args:
                continue
            args = {k: v for k, v in args.items() if k in info.properties and k != "agent_id"}
            log(f"model-proposed args for {name}: {args}")
            res = await self.call(name, args, retries=1)
            if res and "error" not in res:
                self.think(f"Model-proposed arguments unlocked {name}.")
                return True
            tried.append(json.dumps(args)[:80])
        return False

    async def solve(self, state: State) -> State:
        """Plan-act-observe close-out: rank hypotheses, consult the model, self-verify, pick one answer."""
        assert self.gov is not None
        decoded = self._decode()
        if os.getenv("SCOUT_TEST_STALL"):  # test hook: simulate a hung step (watchdog must fire)
            await asyncio.sleep(float(os.getenv("SCOUT_TEST_STALL")))
        for c in self.ctx.clues:  # plaintext claims in raw clues (decoys get penalised)
            self.hyps.absorb_text(c, 1.0, "raw")
        for t in self._tool_texts():  # plaintext claims returned by tools (e.g. a resolved record)
            self.hyps.absorb_text(t, 1.0, "tool")
        computed = numeric.resolve_items(list(self.ctx.clues) + self._tool_texts())
        if computed and not validate_answer(self.strategy.normalize_answer(computed, self.ctx), self.ctx.rules):
            self.hyps.add(self.strategy.normalize_answer(computed, self.ctx), 6.0, "compute")  # exact arithmetic
        self._update_best()
        if os.getenv("SCOUT_DEBUG"):
            log(f"hyps={[(h.answer, round(h.score, 2), h.sources[:2]) for h in self.hyps.ranked()[:4]]}")
        fallback = "" if self._is_logic() else self.best_answer  # gated (never raw decoder junk); may be "" -> model / best evidence
        try:
            self.http.save_draft(self.agent_id, fallback[:500], "deterministic decode")
        except Exception:
            pass
        ranked = self.hyps.probs()
        # a rival clean decode (two intercepts that disagree) means the clues must arbitrate: not confident
        rivals = [h for h, _ in ranked[1:] if "decode" in ",".join(h.sources) and h.score >= self.hyps.NULL_SCORE]
        confident = bool(ranked) and ranked[0][1] >= 0.85 and not rivals and (
            "decode" in ",".join(ranked[0][0].sources) or "compute" in ranked[0][0].sources)
        logic = self._is_logic()
        if self.act.get("consult_model") or logic:
            confident = False  # playbook: this family fools the decoder; always ask the model
        answer = ""
        if rivals and not self.gov.must_submit() and self.ctx.available_models:
            if await self._arbitrate([ranked[0][0]] + rivals[:1]):
                ranked = self.hyps.probs()
                confident = True  # the clue-selected decode wins; skip the open-ended solve call
        if not self.gov.must_submit() and self.ctx.available_models and not confident:
            images = self._images()
            self.model = self._pick_model(need_image=bool(images))
            think = llmpolicy.want_thinking(self.ctx.difficulty, self._to_line(), confident)
            if logic and self._to_line() >= 20:
                think = True  # Practice logic: the fast small-model pass violated stated clues (q=50)
            # token-frugal: only clean decoded evidence + rules, no raw ciphertext once decoded
            good = [DATA_URI_RE.sub("[image attached]", d) for d in decoded[:5] if not d.startswith("data:")]
            clean_ctx = self.ctx
            if images:
                from dataclasses import replace
                clean_ctx = replace(self.ctx, clues=[DATA_URI_RE.sub("[image attached]", c) for c in self.ctx.clues])
            prompt = self.strategy.build_solver_prompt(clean_ctx, good)
            tool_txt = self._tool_texts()
            if tool_txt:
                prompt += "\n\nTOOL RESULTS:\n" + "\n".join(f"- {t[:300]}" for t in tool_txt)
            if self.playbooks:
                prompt += "\n\n" + skills.render(self.playbooks)
            notes = numeric.annotate(list(self.ctx.clues))
            if notes:
                prompt += "\n\nCOMPUTED (exact arithmetic, trust these):\n" + "\n".join(f"- {n}" for n in notes[:8])
            user: Any = prompt
            if images:
                user = [{"type": "text", "text": prompt + "\n\nRead any text in the attached image(s) carefully."}]
                user += [{"type": "image_url", "image_url": {"url": u}} for u in images]
            msgs = [{"role": "system", "content": self.strategy.text_system_prompt},
                    {"role": "user", "content": user}]
            try:
                # fast pass first (thinking off); escalate to one thinking pass only if the fast answer is
                # unusable and the policy allows it (hard, not confident, time to spare)
                answer = ""
                if logic:
                    think = False  # strong models solve these with reasoning off; thinking timed out (60s puzzle)
                    got, self.model = await self._race(msgs, self.strategy.rank_strong(
                        self.strategy.rank_models(self.ctx, self.ctx.available_models))[:RACE_N])
                    if got and not validate_answer(got, self.ctx.rules):
                        answer = got
                passes = [] if (logic and answer) else ([False, True] if think else [False])
                for use_think in passes:
                    if use_think and (self.gov.must_submit() or not (logic or llmpolicy.want_thinking(
                            self.ctx.difficulty, self._to_line(), confident))):
                        break
                    try:
                        text, usage = await asyncio.to_thread(self._llm, msgs, self.strategy.get_llm_params(self.ctx),
                                                              think=use_think, purpose="solve-think" if use_think else "solve")
                    except Exception as e:
                        log(f"llm {'think' if use_think else 'fast'} pass failed: {type(e).__name__}: {e}")
                        break  # a slow/failing backend will not get faster with thinking on: stop here
                    got = self.strategy.normalize_answer(llm.extract_answer(text), self.ctx)
                    if got and not validate_answer(got, self.ctx.rules):
                        answer = got
                        # escalate only on an unusable fast answer, or (SCOUT_THINK=1) when uncorroborated:
                        # on a slow/contended backend a thinking pass costs more speed score than it buys
                        if os.getenv("SCOUT_THINK", "auto") not in ("1", "on", "true") or \
                                got in {h.answer for h, _ in ranked}:
                            break
                if answer and logic:
                    answer = await self._check_logic(msgs, answer)
                    self.raw_case[" ".join(answer.upper().split())] = answer
                    self.logic_answer = answer
                prior = self.hyps.h.get(" ".join(answer.upper().split())) if answer else None
                if prior is not None and prior.score < self.hyps.NULL_SCORE:
                    # the model echoed a claim the evidence already marked as decoy/injection: don't let
                    # agreement lift it over a clean decode (seen: '(void)' decoy won a held-out heat)
                    log(f"model echoed a penalised hypothesis ({prior.answer}); ignoring")
                    answer = ""
                if answer:
                    top = ranked[0][0] if ranked else None
                    decoded_top = bool(top) and any(src.startswith("decode") for src in top.sources)
                    # the model outranks raw-text pattern matches, but not a clean deterministic decode
                    score = (top.score - 0.25) if decoded_top else max(top.score if top else 0.0,
                                                                        self.hyps.NULL_SCORE) + 0.25
                    if self.act.get("trust_model") and top is not None:
                        score = max(top.score, self.hyps.NULL_SCORE) + 0.5  # playbook: the model arbitrates
                    self.hyps.add(answer, score, "model")
            except Exception as e:
                log(f"llm failed: {type(e).__name__}: {e}")
        ranked = self.hyps.probs()
        valid = [(h, p) for h, p in ranked if not validate_answer(h.answer, self.ctx.rules)
                 and not looks_like_junk(h.answer)][:4]
        if len(valid) > 1 and valid[0][1] - valid[1][1] < 0.2 and self.gov.can_explore():
            # close call: spend one extra (cheap, unused) tool call to gather disambiguating evidence
            spare = [t for t in self.tools.values() if t.kind == "unknown" and not t.denied and not t.dead
                     and t.name not in self.ctx.tools_used and not [r for r in t.required if r != "agent_id"]]
            if spare:
                await self.call(spare[0].name, {}, retries=0)
                self._decode()
                ranked = self.hyps.probs()
                valid = [(h, p) for h, p in ranked if not validate_answer(h.answer, self.ctx.rules)
                         and not looks_like_junk(h.answer)][:4]
        if valid:
            answer = valid[0][0].answer
            if self.use_decide and len(valid) > 1 and not self.gov.must_submit() and self.model:
                d = await asyncio.to_thread(
                    decide, self._decide_question(),
                    [f"{h.answer} (from {','.join(h.sources[:2])})" for h, _ in valid], [h.answer for h, _ in valid],
                    [p for _, p in valid], self._chat_fn())
                self.decision_log.append({"method": d.method, "conf": round(d.confidence, 3), "choice": d.best})
                log(f"decide[{d.method}] conf={d.confidence:.2f} margin={d.margin:.2f} -> {d.best}")
                answer = d.best
        if logic and self.logic_answer:
            answer = self.logic_answer  # deduction answer: no decoder hypothesis may override it
        if not answer or validate_answer(answer, self.ctx.rules):
            answer = answer if answer and not validate_answer(answer, self.ctx.rules) else fallback
        if not answer.strip():
            # best evidence: highest-scoring format-valid hypothesis even if ungated, else a placeholder
            ev = [h.answer for h in self.hyps.ranked() if not validate_answer(h.answer, self.ctx.rules)]
            answer = (self.best_answer if not self._is_logic() else "") or (ev[0] if ev and not self._is_logic() else "UNKNOWN")  # never submit empty
        answer = self.raw_case.get(" ".join(answer.upper().split()), answer)  # undo store upper-casing
        self.best_answer = answer
        conf = dict((h.answer, p) for h, p in ranked).get(answer, 0.0)
        if self.decision_log:
            conf = self.decision_log[-1]["conf"] if self.decision_log[-1]["choice"] == answer else conf
        log(f"FINAL conf={conf:.3f} n_hyp={len(ranked)} decide={self.decision_log[-1]['method'] if self.decision_log else 'off'}")
        try:
            self.http.save_draft(self.agent_id, answer[:500], f"model={self.model} conf={conf:.2f}")
        except Exception:
            pass
        self.think(f"Candidate ready (confidence {conf:.0%}, {len(ranked)} hypotheses); verifying before submit.")
        return {**state, "answer": answer}

    async def _race(self, msgs: list[dict[str, Any]], models: list[str]) -> tuple[str, str]:
        """Ask a few roster models in parallel; the first format-valid answer wins (proxy latency per model
        varied 1s..25s on Practice, so a fixed pick either timed out or cost speed score)."""
        if not models:
            return "", self.model
        # roomy max_tokens: some models still emit hidden reasoning; at 1024 they ended with no ANSWER line
        params = {**self.strategy.get_llm_params(self.ctx), "reasoning_effort": "none", "max_tokens": 4096}
        timeout = llmpolicy.call_timeout(self._to_line(), False)

        import requests as _rq
        sessions = {m: _rq.Session() for m in models}  # closing a loser's session aborts its request
        won = {"done": False}

        def one(m: str) -> tuple[str, str, dict[str, Any]]:
            p = dict(params)
            for _ in range(2):
                if won["done"]:
                    raise RuntimeError("race already won")
                try:
                    text, usage = llm.chat(m, msgs, p, self.agent_id, self.usage_scope, timeout, session=sessions[m])
                    return m, text, usage
                except llm.LLMHTTPError as e:
                    if not e.rejected_param(p):
                        raise
                    p.pop(e.rejected_param(p), None)  # e.g. "reasoning is mandatory" -> drop reasoning_effort
            raise RuntimeError("param fallback exhausted")

        t0 = time.monotonic()
        pending = {asyncio.ensure_future(asyncio.to_thread(one, m)) for m in models}
        try:
            while pending:
                done, pending = await asyncio.wait(pending, return_when=asyncio.FIRST_COMPLETED,
                                                   timeout=max(1.0, self._to_line() - 1))
                if not done:
                    break
                for f in done:
                    try:
                        m, text, usage = f.result()
                    except Exception as e:
                        log(f"race member failed: {type(e).__name__}: {str(e)[:120]}")
                        continue
                    self.tokens += int(usage.get("total_tokens") or 0)
                    explicit = llm.ANSWER_RE.search(llm.THINK_RE.sub("", text or ""))  # no first-line guesses
                    got = self.strategy.normalize_answer(llm.extract_answer(text), self.ctx) if explicit else ""
                    self.llm_log.append({"purpose": "race", "model": m, "s": round(time.monotonic() - t0, 2),
                                         "tokens": usage.get("total_tokens"), "answer": got[:80]})
                    if got and not validate_answer(got, self.ctx.rules):
                        log(f"race won by {m} in {time.monotonic() - t0:.1f}s")
                        return got, m
        finally:
            won["done"] = True
            for f in pending:
                f.cancel()
            for s_ in sessions.values():  # abort losers' in-flight HTTP so they stop costing time/tokens
                try:
                    s_.close()
                except Exception:
                    pass
        return "", self.model

    async def _check_logic(self, msgs: list[dict[str, Any]], answer: str) -> str:
        """One self-check pass: test the candidate against every clue; keep it or take the correction.
        A deterministic ordering check runs first: when every clue parses and the order is unique it decides
        (run 118: the model 'corrected' to Bravo-first despite "Bravo does not present first or last");
        otherwise the parsed clues veto a model correction that breaks them."""
        try:
            v = ordering.verdict(list(self.ctx.clues), answer, self.ctx.description or "")
        except Exception as e:  # never let the checker cost the run
            log(f"ordering check failed: {type(e).__name__}: {e}")
            v = {"unique": False, "ok": True, "cons": [], "ks": []}
        if v["unique"] or (v["full"] and v["ok"]):
            self.llm_log.append({"purpose": "ordering-check", "ok": v["ok"], "unique": v["unique"]})
            if v["ok"]:
                # every clue read and satisfied: a model "correction" can only swap to another valid order,
                # and the judge wants one (run 184: easy puzzle has 2 fits; the swap scored quality 0)
                self.think("Deterministic check: the order satisfies every clue.")
                return answer
            if not validate_answer(v["solution"], self.ctx.rules):
                log(f"ordering check corrected {answer!r} -> {v['solution']!r}")
                self.think("Deterministic check found a violated clue; corrected the order.")
                return v["solution"]
        if self._to_line() < 15:
            return answer
        clues = "\n".join(f"{i + 1}. {c[:300]}" for i, c in enumerate(self.ctx.clues[:16]))
        ask = (f"TASK: {self.ctx.description}\nRULES: {self.ctx.rules}\nCLUES:\n{clues}\n\n"
               f"CANDIDATE: {answer}\n\nCheck the candidate against EVERY clue, one line per clue "
               "(OK or VIOLATED). If any clue is violated, find an answer that satisfies all clues. "
               "Last line must be exactly 'ANSWER: <answer>' in the required output format.")
        try:
            text, _ = await asyncio.to_thread(
                self._llm, [msgs[0], {"role": "user", "content": ask}],
                {**self.strategy.get_llm_params(self.ctx), "max_tokens": 2048}, think=False, purpose="logic-check")
        except Exception as e:
            log(f"logic check failed: {type(e).__name__}: {e}")
            return answer
        m = re.findall(r"ANSWER:\s*(.+)", llm.THINK_RE.sub("", text or ""))
        got = self.strategy.normalize_answer(m[-1], self.ctx) if m else ""
        if got and not validate_answer(got, self.ctx.rules):
            if v["cons"] and v["ok"] and not ordering.satisfies(v["cons"], got, v["ks"]):
                log(f"logic check correction {got!r} breaks a parsed clue; keeping {answer!r}")
                return answer
            if got.upper() != answer.upper():
                log(f"logic check corrected {answer!r} -> {got!r}")
                self.think("Self-check found a violated clue; corrected the order.")
            return got
        return answer

    async def image_solve(self, state: State) -> State:
        assert self.gov is not None
        try:
            await self.call("arena.image.broadcast_thought",
                            {"thought": "GauntletScout: analysing the image task."}, retries=0)
        except Exception:
            pass
        analysis = ""
        # pre-analyze only when required: on Practice it returned a preamble line (~8s, no prompt gain);
        # the single post-check analyze below keeps tool breadth and feeds the rationale
        if self.ctx.image_url and "image_analyze" in self.ctx.required_tools:
            res = await self.call("image_analyze", {"image_uri": self.ctx.image_url, **self._vision_args("image_analyze"),
                                                     "question": "Describe the subject, style and layout."})
            analysis = str((res or {}).get("text") or "")
        tool = self.strategy.plan_image_tool(self.ctx, list(self.tools))
        prompt = self.strategy.build_image_prompt(self.ctx, analysis)
        uri = ""
        for _ in range(2):
            margs = self._image_model_args(tool)
            if margs.get("model"):
                self.model = margs["model"]
            if tool == "image_edit" and self.ctx.image_url:
                res = await self.call("image_edit", {"image_uri": self.ctx.image_url, "prompt": prompt, **margs})
            elif tool in self.tools:
                res = await self.call("image_generate", {"prompt": prompt, **margs})
            else:
                res = None
            uri = str((res or {}).get("image_uri") or "")
            if uri:
                self.best_image = uri
            if uri.startswith(("data:image/", "https://", "http://")) or self.gov.must_submit():
                break
        if not uri:
            uri = self.ctx.image_url or ""
        # output check (+ tool coverage): ask image_analyze whether the result meets the prompt
        # once per run: a second analyze never changed the submission and cost ~8s; one keeps tool breadth
        if uri and uri != self.ctx.image_url and "image_analyze" in self.tools \
                and "image_analyze" not in self.ctx.tools_used and self.gov.frac() < 0.5:
            chk = await self.call("image_analyze", {"image_uri": uri, **self._vision_args("image_analyze"), "question":
                                  self.strategy.image_check_question(self.ctx)}, retries=0)
            if chk and "error" not in chk:
                self.think(f"Output check: {str(chk.get('text') or '')[:120]}")
                check = " ".join(str(chk.get("text") or "").split())[:250]
            else:
                check = ""
        else:
            check = ""
        fix = self.strategy.image_violation_fix(check)
        if fix and tool == "image_generate" and not self.ctx.image_url and self.gov.frac() < 0.4 \
                and os.getenv("SCOUT_IMAGE_REGEN", "0") != "0":
            # one targeted regen: Practice judge 'constraints' 66-82 when the check saw text on neon signs
            res = await self.call("image_generate", {"prompt": f"{prompt}\n\n{fix}", **self._image_model_args(tool)})
            new = str((res or {}).get("image_uri") or "")
            if new.startswith(("data:image/", "https://", "http://")):
                uri = self.best_image = new
                check = ""
                self.think("Regenerated once to fix a flagged constraint.")
        efix = self.strategy.image_edit_violation(check)
        if efix and tool == "image_edit" and self.ctx.image_url and self.gov.frac() < 0.4 \
                and os.getenv("SCOUT_EDIT_CHECK", "1") != "0":
            # one re-edit when the check says the edit was missed or identity/background drifted
            res = await self.call("image_edit", {"image_uri": self.ctx.image_url, "prompt": f"{prompt}\n\n{efix}",
                                                 **self._image_model_args(tool)})
            new = str((res or {}).get("image_uri") or "")
            if new.startswith(("data:image/", "https://", "http://")):
                uri = self.best_image = new
                check = ""
                self.think("Re-edited once to fix a flagged preservation issue.")
        self.image_rationale = self.strategy.image_rationale(self.ctx, tool, self.model, check)
        return {**state, "image_uri": uri}

    async def verify(self, state: State) -> State:
        """Make sure every required tool has been called, then (text) re-check the answer."""
        for name in self.ctx.required_tools:
            if name in self.ctx.tools_used or name not in self.tools:
                continue
            if self.tools[name].kind == "submit":
                continue  # the submit node calls it with the real answer; probing it would waste the turn
            if self.gov and self.gov.remaining() < 2:
                break
            extra = {"image_uri": self.ctx.image_url, **self._vision_args(name)} \
                if name == "image_analyze" and self.ctx.image_url else {}
            cands = build_args(self.tools[name], self.agent_id, self.ev)
            for args in cands or [{}]:
                res = await self.call(name, {**args, **extra}, retries=2)
                if res and "error" not in res:
                    break
            if name not in self.ctx.tools_used and [r for r in self.tools[name].required if r != "agent_id"] \
                    and self.gov and self.gov.remaining() > 5:
                await self._model_args(name)  # last resort: a skipped required tool zeroes quality
        if state.get("modality") == "text":
            probs = self.strategy.answer_problems(state.get("answer", ""), self.ctx)
            if probs:
                log(f"verifier: {probs}")
        return state

    async def submit(self, state: State) -> State:
        if self.submitted:
            return state
        self.submitting = True
        if state.get("modality") != "image" and not str(state.get("answer") or "").strip():
            state = {**state, "answer": self.best_answer or "UNKNOWN"}
        if state.get("modality") != "image":
            state = {**state, "answer": format_for_rules(state.get("answer", ""), self.ctx.rules)}
        if self.thoughts == 0:
            self.think("Submitting.")
        self.submitted = True
        metrics = {"model_name": self.model, "total_tokens": self.tokens,
                   "elapsed_s": round(self.gov.elapsed(), 2) if self.gov else None}
        result: dict[str, Any] = {}
        for attempt in range(3):  # retries resend the *identical* answer only
            try:
                if state.get("modality") == "image":
                    assert self.mcp is not None
                    result = await self.mcp.submit_image(self.agent_id, state.get("image_uri", ""), metrics,
                                                         rationale=getattr(self, "image_rationale", "")[:600]
                                                         or "GauntletScout image path")
                else:
                    r = self.http.submit(self.agent_id, state.get("answer", ""), metrics)
                    result = {"accepted": r.accepted, "status": r.status, "score": r.score}
                break
            except ArenaAPIError as e:
                result = {"error": str(e)}
                if e.status_code == 409:
                    break
            except Exception as e:
                result = {"error": str(e)}
            await asyncio.sleep(0.5)
        sc = (result.get("score") or {}) if isinstance(result, dict) else {}
        log(f"submitted: accepted={result.get('accepted')} final={sc.get('final_score')} "
            f"elapsed={metrics['elapsed_s']}s")
        return {**state, "result": result}

    # ------------------------------------------------------------ graph
    def build(self):
        g = StateGraph(State)
        for name in ("boot", "discover", "triage", "explore", "solve", "image_solve", "verify", "submit"):
            g.add_node(name, self._timed(name, getattr(self, name)))
        g.set_entry_point("boot")
        g.add_edge("boot", "discover")
        g.add_edge("discover", "triage")
        g.add_conditional_edges("triage", lambda s: "image_solve" if s["modality"] == "image" else "explore",
                                {"image_solve": "image_solve", "explore": "explore"})
        g.add_conditional_edges("explore", self._explore_more, {"explore": "explore", "solve": "solve"})
        g.add_edge("solve", "verify")
        g.add_edge("image_solve", "verify")
        g.add_edge("verify", "submit")
        g.add_edge("submit", END)
        return g.compile()

    def _timed(self, name: str, fn):
        """Per-node wall time into self.phases (trace) so speed losses can be located."""
        async def wrapped(state: State) -> State:
            t = time.monotonic()
            try:
                return await fn(state)
            finally:
                ph = self.__dict__.setdefault("phases", {})
                ph[name] = round(ph.get(name, 0.0) + time.monotonic() - t, 2)
        return wrapped

    def _emergency_state(self) -> State:
        return {"modality": self.ctx.challenge_type, "answer": self.best_answer or "UNKNOWN",
                "image_uri": self.best_image or self.ctx.image_url or ""}

    async def run(self) -> State:
        await self._connect()
        if self.mcp is None:
            raise RuntimeError("could not connect to MCP")
        graph = self.build()
        hard_cap = float(os.getenv("SCOUT_HARD_CAP_S", "170"))
        self._t0 = time.monotonic()
        task = asyncio.create_task(graph.ainvoke({}, {"recursion_limit": 25}))
        # watchdog: at the submit line, cancel whatever step is running and submit the best draft
        while not task.done():
            await asyncio.sleep(0.2)
            over = self.gov.must_submit() if self.gov else (
                not getattr(self, "in_lobby", False) and (time.monotonic() - self._t0) > hard_cap)
            if over and not self.submitting and not self.submitted:
                log("watchdog: submit line reached mid-step; emergency submit")
                task.cancel()
                try:
                    await task
                except BaseException:
                    pass
                return await self.submit(self._emergency_state())
        try:
            return task.result()
        except LobbyTimeout as e:
            log(f"lobby timeout ({e}); exiting without submit")
            return {"result": {"error": "lobby_timeout"}}
        except Exception as e:
            log(f"graph crashed: {type(e).__name__}: {e}; emergency submit")
            return await self.submit(self._emergency_state())
        finally:
            try:
                await asyncio.wait_for(self.mcp.__aexit__(None, None, None), timeout=1.0)
            except BaseException:
                pass


def _trace(scout: "Scout", out: State) -> None:
    """Optional run trace (SCOUT_TRACE=path): challenge, tool calls, LLM log, answer, result."""
    path = os.getenv("SCOUT_TRACE")
    if not path:
        return
    def strip(v: Any) -> Any:  # inline images would truncate the score/judge out of the trace
        if isinstance(v, dict):
            return {k: strip(x) for k, x in v.items()}
        if isinstance(v, list):
            return [strip(x) for x in v]
        return "<image>" if isinstance(v, str) and v.startswith("data:image") else v

    def short(v: Any) -> Any:
        v = strip(v)
        s = json.dumps(v, default=str)
        return v if len(s) < 1500 else s[:1500] + "...<trunc>"
    data = {"agent_id": scout.agent_id, "challenge": short(scout.challenge),
            "tools": sorted(scout.tools), "required": scout.ctx.required_tools,
            "tools_used": scout.ctx.tools_used, "model": scout.model, "tokens": scout.tokens,
            "thoughts": scout.thoughts, "llm_log": scout.llm_log, "phases": getattr(scout, "phases", {}),
            "calls": [{"tool": k[0], "result": short(v)} for k, v in scout.memory["calls"].items()],
            "answer": short(out.get("answer")), "image_uri": short(out.get("image_uri")),
            "result": short({k: v for k, v in (out.get("result") or {}).items() if k != "edited_image"}),
            "elapsed_s": round(scout.gov.elapsed(), 2) if scout.gov else None}
    text = json.dumps(data, indent=1, default=str)
    try:
        Path(path).write_text(text)
    except OSError:  # sandbox: code dir read-only, only /tmp writable
        Path("/tmp", Path(path).name or "scout_trace.json").write_text(text)
    uri = str(out.get("image_uri") or "")
    if os.getenv("SCOUT_TRACE_IMAGE") and uri.startswith("data:image/") and ";base64," in uri:
        import base64  # harness-only: keep the submitted image next to the trace for offline review
        try:
            Path(path + ".img").write_bytes(base64.b64decode(uri.split(",", 1)[1]))
        except (OSError, ValueError):
            pass


def main() -> int:
    scout = Scout()
    out = asyncio.run(scout.run())
    try:
        _trace(scout, out)
    except Exception as e:  # tracing must never break a run
        log(f"trace failed: {e}")
    return 0 if out.get("result") and "error" not in out["result"] else 1


if __name__ == "__main__":
    _code = main()
    # don't let asyncio's executor shutdown wait on an abandoned race thread (seen: 4 min hang after submit)
    sys.stdout.flush(); sys.stderr.flush()
    os._exit(_code)
