"""Hypothesis tracker: every candidate answer with its provenance and a score; one validation gate."""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field

MARKER_RE = re.compile(r"\b(?:pass\s*phrase|password|passcode|answer|secret)\s+(?:is|=|:)\s*"
                       r"((?:[A-Za-z]+[ \t]*){1,4})", re.I)
DECOY_RE = re.compile(r"(rumou?r|unconfirmed|hearsay|revoked|expired|void|stale|superseded|obsolete|old|example|do not use|fake|decoy|"
                      r"rotated out|deprecated|invalid|not the)", re.I)
# "the passphrase is NOT kestrel lantern": an explicit rule-out of a candidate (negation scenario)
NEG_MARKER_RE = re.compile(r"\b(?:pass\s*phrase|password|passcode|answer|secret)\s+(?:is|was)\s+not\s+"
                           r"((?:[A-Za-z]+[ \t]*){1,4})", re.I)
NEG_PENALTY = 6.0
INJECTION_RE = re.compile(r"(ignore (all |any )?previous|system\s*:|override|operator|debug|submit .* immediately)", re.I)
STOP = {"AND", "THE", "OR", "BUT", "NOW", "IS", "WAS"}
# a capture containing these is prose ("the passphrase is the only bird among ..."), not a claim
FUNCTION = {"THE", "A", "AN", "ONLY", "OF", "AMONG", "IN", "ON", "AT", "TO", "FROM", "WITH", "BY", "NOT", "WORD",
            "ITEM", "NUMBER", "WRITTEN", "SHOWN", "HIDDEN", "HELD", "STORED", "BELOW", "ABOVE", "THIS", "THAT",
            "WHICH", "WHAT", "YOUR", "IT", "ONE", "TWO", "THREE"}


@dataclass
class Hyp:
    answer: str
    score: float
    sources: list[str] = field(default_factory=list)


class Hypotheses:
    def __init__(self) -> None:
        self.h: dict[str, Hyp] = {}
        self.negated: set[str] = set()

    def add(self, answer: str, score: float, source: str) -> None:
        a = " ".join(answer.upper().split())
        if not a:
            return
        if a in self.negated:
            score -= NEG_PENALTY
        cur = self.h.get(a)
        if cur is None:
            self.h[a] = Hyp(a, score, [source])
        else:  # independent agreement raises confidence
            cur.score = max(cur.score, score) + 0.5
            if source not in cur.sources:
                cur.sources.append(source)

    def absorb_text(self, text: str, base: float, source: str) -> None:
        """Extract 'passphrase is X Y' style claims; penalise decoy / injection context."""
        for line in re.split(r"[\n;]|(?<=[.!?])\s", text):
            for m in NEG_MARKER_RE.finditer(line):
                self._negate(m.group(1))
            for m in MARKER_RE.finditer(line):
                words = [w for w in m.group(1).split() if w.isalpha()]
                while words and words[-1].upper() in STOP:
                    words.pop()
                if not words or any(w.upper() in FUNCTION for w in words):
                    continue
                s = base + 2.0
                ctx = line[max(0, m.start() - 40): m.end() + 40]
                if DECOY_RE.search(ctx):
                    s -= 4.0
                if INJECTION_RE.search(line):
                    s -= 6.0
                self.add(" ".join(words), s, source)

    def _negate(self, capture: str) -> None:
        words = [w for w in capture.split() if w.isalpha()]
        while words and words[-1].upper() in STOP:
            words.pop()
        if not words or any(w.upper() in FUNCTION for w in words):
            return  # prose ("is not the only ..."), not a rule-out
        a = " ".join(w.upper() for w in words)
        if a in self.negated:
            return
        self.negated.add(a)
        h = self.h.get(a)
        if h is not None:
            h.score -= NEG_PENALTY

    def favour_latest(self, clues: list[str]) -> str | None:
        """Dated memos + a "most recent one wins" rule: back the latest memo's claim (if it is not a decoy)."""
        latest = latest_dated_claim(clues)
        if latest is None:
            return None
        m = MARKER_RE.search(latest)
        words = [w for w in m.group(1).split() if w.isalpha()] if m else []
        while words and words[-1].upper() in STOP:
            words.pop()
        h = self.h.get(" ".join(w.upper() for w in words))
        if h is None or h.score < self.NULL_SCORE:
            return None
        self.add(h.answer, RECENCY_SCORE, "recency")
        return h.answer

    def adjust_claims(self, text: str, delta: float) -> None:
        """Shift the score of claims already extracted from `text` (no agreement bonus, unlike add)."""
        for m in MARKER_RE.finditer(text):
            words = [w for w in m.group(1).split() if w.isalpha()]
            while words and words[-1].upper() in STOP:
                words.pop()
            h = self.h.get(" ".join(w.upper() for w in words))
            if h is not None:
                h.score += delta

    def ranked(self) -> list[Hyp]:
        return sorted(self.h.values(), key=lambda x: x.score, reverse=True)

    NULL_SCORE = 3.0  # implicit "none of these is right" hypothesis, keeps lone weak guesses unconfident

    def probs(self, temp: float = 1.0) -> list[tuple[Hyp, float]]:
        r = self.ranked()
        if not r:
            return []
        mx = max(r[0].score, self.NULL_SCORE)
        ex = [math.exp((x.score - mx) / temp) for x in r]
        z = sum(ex) + math.exp((self.NULL_SCORE - mx) / temp)
        return [(x, e / z) for x, e in zip(r, ex)]


MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"]
_MON = r"(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?"
DATE_RES = [(re.compile(r"\b(\d{4})-(\d{1,2})-(\d{1,2})\b"), "ymd"),
            (re.compile(rf"\b(\d{{1,2}})\s+{_MON},?\s+(\d{{4}})\b", re.I), "dmy"),
            (re.compile(rf"\b{_MON}\s+(\d{{1,2}}),?\s+(\d{{4}})\b", re.I), "mdy")]
RECENCY_RE = re.compile(r"most recent|latest|newest|replaces (?:all )?(?:earlier|previous|older)|supersede", re.I)
RECENCY_SCORE = 6.0  # a stated "most recent wins" rule is deterministic evidence, like exact arithmetic


def clue_date(text: str) -> tuple[int, int, int] | None:
    """First date in a clue as (y, m, d): '2026-05-02', '2 May 2026', 'Feb 21, 2026'."""
    best = None
    for rx, kind in DATE_RES:
        m = rx.search(text)
        if not m or (best is not None and m.start() >= best[0]):
            continue
        g = m.groups()
        if kind == "ymd":
            ymd = (int(g[0]), int(g[1]), int(g[2]))
        elif kind == "dmy":
            ymd = (int(g[2]), MONTHS.index(g[1].lower()[:3]) + 1, int(g[0]))
        else:
            ymd = (int(g[2]), MONTHS.index(g[0].lower()[:3]) + 1, int(g[1]))
        best = (m.start(), ymd)
    return best[1] if best else None


def latest_dated_claim(clues: list[str]) -> str | None:
    """When the clues say the most recent memo wins, the claim-bearing clue with the latest date (else None)."""
    if not any(RECENCY_RE.search(c) for c in clues):
        return None
    dated = [(d, c) for c in clues if MARKER_RE.search(c) and (d := clue_date(c)) is not None]
    if len(dated) < 2:
        return None
    dated.sort(key=lambda x: x[0])
    return dated[-1][1] if dated[-1][0] != dated[-2][0] else None


PROV_LABEL_RE = re.compile(r"signature|signed|verif|authentic", re.I)


def provenance_delta(clue: str) -> float:
    """Score shift for a claim decoded from `clue`, judged by the clue's label (text before the first ':').
    'HQ [signature: INVALID] intercept (hex): ...' -> penalty; '[signature: valid]' -> bonus; unlabeled -> 0.
    Needed because decoders see only the ciphertext, so a forged copy decoded as cleanly as the real one."""
    start = clue.find("]") + 1  # '[signature: valid]' holds a ':' itself: the label ends at the next one
    end = clue.find(":", start)
    label = clue[:end] if end > 0 else ""
    if not PROV_LABEL_RE.search(label) and not re.search(r"\bunsigned\b", label, re.I):
        return 0.0
    if re.search(r"invalid|unsigned|unverified|not verified|fail|forged|bad", label, re.I):
        return -4.0
    if re.search(r"\bvalid\b|verified|verifies|authentic", label, re.I):
        return 2.0
    return 0.0


def validate_answer(answer: str, rules: str) -> list[str]:
    """Single validation function every candidate (decode, model, fallback) must pass."""
    probs = []
    a = answer.strip()
    if not a:
        probs.append("empty")
    if a.lower() in {"unknown", "n/a", "none", "no idea", "i don't know"}:
        probs.append("non-answer")
    if INJECTION_RE.search(a) or a.upper() in {"HELLO WORLD", "OVERRIDE NOW"}:
        probs.append("injection-echo")
    if len(a) > 200:
        probs.append("too long")
    r = (rules or "").lower()
    if "uppercase" in r and a != a.upper():
        probs.append("case")
    if "passphrase" in r and a and not re.fullmatch(answer_pattern(rules), a.upper()):
        probs.append("format")
    return probs


def answer_pattern(rules: str) -> str:
    """Accepted answer shape, widened only when the rules ask for it (digits, hyphen-joined words)."""
    r = (rules or "").lower()
    word = r"[A-Z0-9]+" if re.search(r"\b(digits?|numbers?|numeric)\b", r) else r"[A-Z]+"
    sep = r"[ -]" if re.search(r"hyphen", r) else " "
    return rf"{word}(?:{sep}{word}){{0,5}}"


def format_for_rules(answer: str, rules: str) -> str:
    """Apply output-format rules the hypothesis store cannot keep (it is upper-case, space-joined)."""
    r = (rules or "").lower()
    a = " ".join(str(answer or "").split())
    if re.search(r"joined (?:by|with) (?:a |one |single )*hyphen", r):
        a = "-".join(a.replace("-", " ").split())
    if "lowercase" in r and "uppercase" not in r:
        a = a.lower()
    return a


def looks_like_junk(answer: str) -> bool:
    """Answer gate for fallbacks: reject decoder junk such as reversed 'no such entry' ('YRTNE HCUS ON'),
    pure function-word phrases, and unpronounceable strings."""
    from gauntletscout.codec import english_score
    a = " ".join(answer.upper().split())
    words = a.split()
    if not words:
        return True
    if all(w in FUNCTION or w in STOP or w.lower() in {"no", "such", "entry", "empty", "none", "silent"} for w in words):
        return True
    rev = a[::-1]
    if english_score(rev) > english_score(a) + 2.0:  # reads better backwards: an un-reversed decode
        return True
    if any(re.search(r"[BCDFGHJKLMNPQRSTVWXZ]{5,}", w) or not re.search(r"[AEIOUY]", w) for w in words if len(w) > 2):
        return True
    return False
