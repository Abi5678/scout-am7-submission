"""Deterministic arithmetic over clue text: a safe evaluator (AST whitelist, no eval of names/calls)
plus a resolver for 'item number (<expr>)' against a numbered list in the clues."""
from __future__ import annotations

import ast
import operator
import re

_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.FloorDiv: operator.floordiv,
        ast.Div: operator.truediv, ast.Mod: operator.mod, ast.Pow: operator.pow, ast.USub: operator.neg,
        ast.UAdd: operator.pos}
_WORDS = [(r"\bsquared\b", "**2"), (r"\bcubed\b", "**3"), (r"\bplus\b", "+"), (r"\bminus\b", "-"),
          (r"\b(times|multiplied by)\b", "*"), (r"\bdivided by\b", "/"), (r"\bmod(ulo)?\b", "%"),
          (r"\bto the power of\b", "**"), (r"[×x](?=\s*\d)", "*"), (r"÷", "/"), (r"−", "-")]
EXPR_RE = re.compile(r"\(([^()]*\d[^()]*)\)")
LIST_RE = re.compile(r"\b(\d{1,3})\s*[=:.)]\s*([A-Za-z][A-Za-z'-]*)")
ITEM_RE = re.compile(r"\bword\s+(\d+)\b.*?\bitem(?:\s+number)?\s*(\(.*\))", re.I)


def outer_groups(text: str) -> list[str]:
    """Contents of top-level balanced (...) groups (handles nesting like '((4 * 5) - 12)')."""
    out, depth, start = [], 0, 0
    for i, ch in enumerate(text):
        if ch == "(":
            if depth == 0:
                start = i + 1
            depth += 1
        elif ch == ")" and depth:
            depth -= 1
            if depth == 0:
                out.append(text[start:i])
    return out


def safe_eval(expr: str) -> float | None:
    """Evaluate +-*/ % ** on numeric literals (and 'squared', 'plus', ... words). None if not pure arithmetic."""
    s = expr.strip()
    for pat, rep in _WORDS:
        s = re.sub(pat, rep, s, flags=re.I)
    if not re.fullmatch(r"[\d\s+\-*/%().]+", s) or len(s) > 80:
        return None
    try:
        tree = ast.parse(s, mode="eval")
    except SyntaxError:
        return None

    def ev(n: ast.AST) -> float:
        if isinstance(n, ast.Expression):
            return ev(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)):
            return n.value
        if isinstance(n, ast.BinOp) and type(n.op) in _OPS:
            a, b = ev(n.left), ev(n.right)
            if isinstance(n.op, ast.Pow) and (abs(b) > 6 or abs(a) > 1000):
                raise ValueError("pow too large")
            return _OPS[type(n.op)](a, b)
        if isinstance(n, ast.UnaryOp) and type(n.op) in _OPS:
            return _OPS[type(n.op)](ev(n.operand))
        raise ValueError("disallowed")

    try:
        v = ev(tree)
    except (ValueError, ZeroDivisionError, OverflowError, TypeError):
        return None
    return int(v) if float(v).is_integer() else v


def annotate(texts: list[str]) -> list[str]:
    """'(4 squared minus 12) = 4' notes for every parenthesised arithmetic expression (for the LLM prompt)."""
    out = []
    for t in texts:
        for g in outer_groups(t):
            v = safe_eval(g) if re.search(r"\d", g) else None
            if v is not None and not re.fullmatch(r"\s*\d+\s*", g):
                out.append(f"({g.strip()}) = {v}")
    return out


def resolve_items(texts: list[str]) -> str | None:
    """Assemble 'Word k is list item number (<expr>)' clues against a numbered list -> answer words."""
    listing: dict[int, str] = {}
    for t in texts:
        found = LIST_RE.findall(t)
        if len(found) >= 3:
            listing.update({int(i): w for i, w in found})
    if not listing:
        return None
    picks: dict[int, str] = {}
    for t in texts:
        for m in ITEM_RE.finditer(t):
            groups = outer_groups(m.group(2))
            v = safe_eval(groups[0]) if groups else None
            if isinstance(v, int) and v in listing:
                picks[int(m.group(1))] = listing[v]
    if not picks or sorted(picks) != list(range(1, len(picks) + 1)):
        return None
    return " ".join(picks[k] for k in sorted(picks))
