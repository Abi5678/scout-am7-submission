"""Wall-clock time governor: explore until 60%, force submit by 80% of max_time_s."""
from __future__ import annotations

import time
from dataclasses import dataclass


@dataclass
class Governor:
    max_time_s: float
    started: float
    explore_frac: float = 0.60
    submit_frac: float = 0.80
    safety_s: float = 3.0

    @classmethod
    def start(cls, max_time_s: float, time_remaining_s: float | None = None, **kw) -> "Governor":
        now = time.monotonic()
        total = float(max_time_s or 60)
        # if the server timer already ran, anchor to what is actually left
        elapsed = max(0.0, total - float(time_remaining_s)) if time_remaining_s else 0.0
        return cls(total, now - elapsed, **kw)

    def elapsed(self) -> float:
        return time.monotonic() - self.started

    def frac(self) -> float:
        return self.elapsed() / self.max_time_s

    def remaining(self) -> float:
        return self.max_time_s - self.elapsed()

    def can_explore(self) -> bool:
        return self.frac() < self.explore_frac

    def must_submit(self) -> bool:
        return self.frac() >= self.submit_frac or self.remaining() <= self.safety_s

    def budget(self, cap: float) -> float:
        """Timeout for one operation: never past the submit line."""
        to_line = self.max_time_s * self.submit_frac - self.elapsed()
        return max(0.5, min(cap, to_line))
