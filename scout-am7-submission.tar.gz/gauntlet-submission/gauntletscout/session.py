"""MCP session lifetime: each session is opened and closed by one dedicated owner task.

sse_client and ClientSession hold anyio cancel scopes, which must exit in the task that entered them. A session left
to the garbage collector is finalized in a new task, raises 'Attempted to exit cancel scope in a different task' and
cancels whichever task entered it (Practice 902/903/905). Here that task is the owner, which does nothing else.
"""
from __future__ import annotations

import asyncio
import functools
import logging
import time
from typing import Any, Callable

import httpx
from mcp import ClientSession
from mcp.client.sse import sse_client

from arena_clients.mcp_client import McpArenaClient

CLOSE_CAP_S = 2.0
LIVE_POLL_S = 0.25
PING_CAP_S = 3.0
# The kit's sse_client default gives every POST 5 s, and one failed POST ends the session's writer for good: Practice
# 901 WriteTimeout sending a 1.9 MB image, 905 ConnectTimeout re-dialing after the 5 s keep-alive expired.
POST_CONNECT_S = 15.0
POST_WRITE_S = 30.0
KEEPALIVE_S = 60.0

_log = logging.getLogger("gauntletscout.session")


class PostLog:
    """When the server last accepted (HTTP 2xx) a POST carrying submit_edit on this session: from then on the
    submission is in the server's hands, even if the tool's reply is slow to come back."""

    def __init__(self) -> None:
        self.submit_accepted = 0.0

    async def on_response(self, response: httpx.Response) -> None:
        req = response.request
        if req.method == "POST" and response.status_code < 300:
            try:
                head = req.content[:1024]
            except Exception:
                return
            if b"arena.image.submit_edit" in head:
                self.submit_accepted = time.monotonic()


def _http_client(headers: dict[str, str] | None = None, timeout: httpx.Timeout | None = None,
                 auth: httpx.Auth | None = None, posts: PostLog | None = None) -> httpx.AsyncClient:
    read = timeout.read if timeout is not None else 300.0
    return httpx.AsyncClient(follow_redirects=True, headers=headers, auth=auth,
                             timeout=httpx.Timeout(POST_CONNECT_S, write=POST_WRITE_S, read=read),
                             limits=httpx.Limits(keepalive_expiry=KEEPALIVE_S),
                             event_hooks={"response": [posts.on_response]} if posts else None)


class ArenaMcpClient(McpArenaClient):
    """The kit client with POST timeouts that survive a slow link and a log of delivered submits (the kit's
    arena_clients/ stay unedited)."""

    async def __aenter__(self) -> "ArenaMcpClient":
        self.posts = PostLog()
        self._context = sse_client(self.sse_url, headers=self._headers,
                                   httpx_client_factory=functools.partial(_http_client, posts=self.posts))
        read, write = await self._context.__aenter__()
        self._session = ClientSession(read, write)
        await self._session.__aenter__()
        await self._session.initialize()
        return self


def session_broken(client: Any) -> bool:
    """True once the transport's POST writer has died: nothing sent on this session can ever be answered."""
    try:
        return client._session._write_stream.statistics().open_receive_streams == 0
    except Exception:
        return False


async def call_live(client: Any, aw: Any, timeout: float) -> Any:
    """Await one call on `client`, time-boxed, failing at once if the writer dies (it used to hang to the cap:
    Practice 901 image_analyze 57 s). Raises TimeoutError, or ConnectionError for a dead writer."""
    task = asyncio.ensure_future(aw)
    task.add_done_callback(lambda f: f.cancelled() or f.exception())
    end = time.monotonic() + timeout
    try:
        while True:
            left = end - time.monotonic()
            if left <= 0:
                raise asyncio.TimeoutError
            done, _ = await asyncio.wait({task}, timeout=min(LIVE_POLL_S, left))
            if done:
                if task.cancelled():
                    raise ConnectionError("connection lost: mcp call cancelled")
                return task.result()
            if session_broken(client):
                raise ConnectionError("connection lost: mcp post writer died")
    finally:
        if not task.done():
            task.cancel()


async def session_alive(client: Any, cap: float = PING_CAP_S) -> bool:
    """False when the session cannot answer a ping (clients without a real session count as alive)."""
    session = getattr(client, "_session", None)
    if session is None:
        return True
    try:
        await call_live(client, session.send_ping(), cap)
        return True
    except Exception:
        return False


class OwnedSession:
    """One MCP session whose whole lifetime runs in one task. Calls may come from any task."""

    def __init__(self, factory: Callable[[], Any]) -> None:
        self._factory = factory
        self._ready: asyncio.Future[Any] | None = None
        self._stop = asyncio.Event()
        self.task: asyncio.Task[None] | None = None

    async def open(self, timeout: float) -> Any:
        """Connected client, or the failure. A timeout cuts the open inside the owner, so the caller is never hit."""
        self._ready = asyncio.get_running_loop().create_future()
        self.task = asyncio.create_task(self._own(), name="mcp-session-owner")
        try:
            done, _ = await asyncio.wait({self._ready}, timeout=timeout)
        except BaseException:
            self.close()
            raise
        if not done:
            self.close()
            raise asyncio.TimeoutError(f"mcp open exceeded {timeout:.1f}s")
        return self._ready.result()

    def close(self) -> None:
        """Ask the owner to finish; never waits (the owner's close is capped, a submit must not sit behind it)."""
        self._stop.set()
        if self.task is not None and self._ready is not None and not self._ready.done():
            self.task.cancel()  # still opening: cut it, in the task that is doing the opening

    async def _own(self) -> None:
        client = None
        try:
            client = self._factory()
            await client.__aenter__()
            self._ready.set_result(client)
            await self._stop.wait()
        except (KeyboardInterrupt, SystemExit):
            raise
        except BaseException as e:  # a cut open, or the transport's task group cancelling its host: session over
            if self._stop.is_set():  # the opener already gave up: nobody is left to read this
                self._ready.cancel()
            elif not self._ready.done():
                self._ready.set_exception(e if isinstance(e, Exception) else ConnectionError(f"mcp open: {e!r}"))
            _log.debug("mcp session ended: %r", e)
        await self._finalize(client)

    @staticmethod
    async def _finalize(client: Any) -> None:
        if client is None:
            return
        task = asyncio.current_task()
        while task is not None and task.cancelling():
            task.uncancel()
        try:
            async with asyncio.timeout(CLOSE_CAP_S):
                await client.__aexit__(None, None, None)
            return
        except (KeyboardInterrupt, SystemExit):
            raise
        except BaseException as e:
            _log.debug("mcp session close: %r", e)
        # the session half failed to close: still release the transport generator here, not in a GC finalizer
        ctx = getattr(client, "_context", None)
        if ctx is not None:
            while task is not None and task.cancelling():
                task.uncancel()
            try:
                async with asyncio.timeout(CLOSE_CAP_S):
                    await ctx.__aexit__(None, None, None)
            except (KeyboardInterrupt, SystemExit):
                raise
            except BaseException as e:
                _log.debug("mcp transport close: %r", e)
