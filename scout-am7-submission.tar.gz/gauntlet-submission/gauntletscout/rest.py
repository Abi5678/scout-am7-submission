"""The kit REST client over one keep-alive pool, plus a timing log for the run trace.

Practice 11-02: a new connection took 0.5-2.5 s (DNS up to 1.6, TCP up to 1.3, TLS up to 1.0) and a reused one 0.1-0.5 s,
still usable after 100 s idle. The kit opens a new connection per call, and the speed clock runs until the submit POST
reaches the server. Text submits go over their own connection, warmed ahead of time, so a thought or draft still in
flight cannot make them dial a new one.
"""
from __future__ import annotations

import os
import threading
import time
from typing import Any

import requests
from requests.adapters import HTTPAdapter
from urllib3.exceptions import NewConnectionError

from arena_clients.http_client import ArenaAPIError, ArenaConnectionError, HttpArenaClient

# Nothing has been sent when connecting fails, so any method may retry. Together these stay under the kit's flat 30 s.
CONNECT_CAPS_S = (3.0, 6.0, 12.0)
CONNECT_RETRY_WAIT_S = 0.2
POOL_SIZE = 8
SUBMIT_PATH = "/api/submit"


def rest_pool_enabled() -> bool:
    """Keep-alive REST and the submit path that relies on it. Default on; SCOUT_REST_POOL=0 restores the kit client."""
    return os.getenv("SCOUT_REST_POOL", "1") != "0"


def _session() -> requests.Session:
    s = requests.Session()
    s.mount("https://", HTTPAdapter(pool_connections=1, pool_maxsize=POOL_SIZE))
    s.mount("http://", HTTPAdapter(pool_connections=1, pool_maxsize=POOL_SIZE))
    return s


def _never_connected(e: requests.ConnectionError) -> bool:
    """A connect timeout, DNS failure or refused connection. A reset on a live connection may have delivered the POST."""
    if isinstance(e, requests.ConnectTimeout):
        return True
    reason = getattr(e.args[0], "reason", None) if e.args else None
    return isinstance(reason, NewConnectionError)


class ArenaRestClient(HttpArenaClient):
    """HttpArenaClient with the same errors and read timeout; only the connection handling differs when pooled."""

    def __init__(self, pooled: bool | None = None, **kw: Any) -> None:
        super().__init__(**kw)
        self.pooled = rest_pool_enabled() if pooled is None else pooled
        self._general = _session() if self.pooled else None
        self._submit = _session() if self.pooled else None
        self._t0 = time.monotonic()
        self._log_lock = threading.Lock()
        self.rest_log: list[dict[str, Any]] = []

    def warm_submit(self) -> None:
        """Open the submit connection ahead of the answer. Best effort: a miss just dials at submit time."""
        if self.pooled:
            try:
                self._submit.get(f"{self.api_base}/api/health", timeout=(CONNECT_CAPS_S[-1], self.timeout)).content
            except requests.RequestException:
                pass

    def _send(self, method: str, path: str, data: dict[str, Any] | None) -> dict[str, Any]:
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["X-Arena-API-Key"] = self.api_key
        session = self._submit if path == SUBMIT_PATH else self._general
        for attempt, cap in enumerate(CONNECT_CAPS_S):
            try:
                response = session.request(method, f"{self.api_base}{path}", headers=headers,
                                           json=data if data is not None else None, timeout=(cap, self.timeout))
                if response.status_code >= 400:
                    raise ArenaAPIError(response.status_code, response.text)
                return response.json()
            except requests.ConnectionError as e:
                if attempt + 1 == len(CONNECT_CAPS_S) or not _never_connected(e):
                    raise ArenaConnectionError(str(e)) from e
                time.sleep(CONNECT_RETRY_WAIT_S)
            except requests.RequestException as e:
                raise ArenaConnectionError(str(e)) from e
        raise AssertionError("unreachable")

    def _request(self, method: str, path: str, data: dict[str, Any] | None = None) -> dict[str, Any]:
        start = time.monotonic()
        status = "ok"
        try:
            return self._send(method, path, data) if self.pooled else super()._request(method, path, data)
        except Exception as e:
            status = str(getattr(e, "status_code", type(e).__name__))
            raise
        finally:
            with self._log_lock:
                self.rest_log.append({"call": f"{method} {path}", "at": round(start - self._t0, 2),
                                      "s": round(time.monotonic() - start, 2), "status": status})
