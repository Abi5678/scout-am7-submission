"""Pure-Python codec sandbox: brute-force common encodings and rank by English likelihood.

No model calls, no network, no file I/O. Bounded work: every transform is O(len(text))
and the candidate count is capped, so a pathological clue cannot hang the agent.
"""
from __future__ import annotations

import base64
import binascii
import re
from dataclasses import dataclass
from urllib.parse import unquote

MAX_INPUT = 4096
COMMON = set(
    "the be to of and a in that have i it for not on with he as you do at this but his by from they we "
    "say her she or an will my one all would there their what so up out if about who get which go me "
    "is are was were key code answer pass passphrase password secret word message flag record archive "
    "entry ledger token clue hidden find use value number name".split()
)
MORSE_REV = {
    ".-": "A", "-...": "B", "-.-.": "C", "-..": "D", ".": "E", "..-.": "F", "--.": "G", "....": "H",
    "..": "I", ".---": "J", "-.-": "K", ".-..": "L", "--": "M", "-.": "N", "---": "O", ".--.": "P",
    "--.-": "Q", ".-.": "R", "...": "S", "-": "T", "..-": "U", "...-": "V", ".--": "W", "-..-": "X",
    "-.--": "Y", "--..": "Z", "-----": "0", ".----": "1", "..---": "2", "...--": "3", "....-": "4",
    ".....": "5", "-....": "6", "--...": "7", "---..": "8", "----.": "9",
}
# English letter frequencies (percent) for a chi-squared tie-breaker.
FREQ = dict(zip("ETAOINSHRDLCUMWFGYPBVKJXQZ",
                [12.7, 9.1, 8.2, 7.5, 7.0, 6.7, 6.3, 6.1, 6.0, 4.3, 4.0, 2.8, 2.8, 2.4, 2.4, 2.2, 2.0,
                 2.0, 1.9, 1.5, 1.0, 0.8, 0.15, 0.15, 0.1, 0.07]))


@dataclass(frozen=True)
class Candidate:
    text: str
    method: str
    score: float


def english_score(text: str) -> float:
    if not text:
        return -1e9
    printable = sum(32 <= ord(c) < 127 for c in text) / len(text)
    if printable < 0.95:
        return -100.0 + printable
    words = re.findall(r"[A-Za-z]+", text)
    if not words:
        return -50.0
    total = sum(len(w) for w in words)
    common = sum(len(w) for w in words if len(w) > 1 and w.lower() in COMMON) / max(1, total)
    digits = sum(c.isdigit() for c in text) / len(text)
    letters = [c for c in text.upper() if "A" <= c <= "Z"]
    chi = 0.0
    if letters:
        n = len(letters)
        for ch, f in FREQ.items():
            exp = n * f / 100
            chi += (letters.count(ch) - exp) ** 2 / max(exp, 0.01)
    alpha_ratio = sum(c.isalpha() or c == " " for c in text) / len(text)
    symbols = sum(not (c.isalnum() or c in " .,:;'!?-=()") for c in text) / len(text)
    short = 3.0 if total < 8 else 0.0  # 4-char junk ("we{~") must not outrank real sentences
    return 10 * common + 3 * alpha_ratio - min(chi, 500) / 100 - 5 * digits - 8 * symbols - short


def rot(text: str, n: int) -> str:
    return "".join(
        chr((ord(c) - 97 + n) % 26 + 97) if "a" <= c <= "z"
        else chr((ord(c) - 65 + n) % 26 + 65) if "A" <= c <= "Z" else c
        for c in text
    )


def atbash(text: str) -> str:
    return "".join(chr(155 - ord(c)) if "A" <= c <= "Z" else chr(219 - ord(c)) if "a" <= c <= "z" else c
                   for c in text)


def vigenere_decrypt(text: str, key: str) -> str:
    key = re.sub(r"[^A-Za-z]", "", key).upper()
    if not key:
        return text
    out, i = [], 0
    for c in text:
        if c.isalpha() and c.isascii():
            out.append(rot(c, -(ord(key[i % len(key)]) - 65)))
            i += 1
        else:
            out.append(c)
    return "".join(out)


def _try_b64(s: str) -> str | None:
    t = s.strip()
    if len(t) < 8 or not re.fullmatch(r"[A-Za-z0-9+/=_-]+", t):
        return None
    try:
        raw = base64.b64decode(t + "=" * (-len(t) % 4), altchars=b"-_" if ("-" in t or "_" in t) else None, validate=False)
        return raw.decode("utf-8")
    except (binascii.Error, UnicodeDecodeError, ValueError):
        return None


def _try_b32(s: str) -> str | None:
    t = s.strip().upper()
    if len(t) < 8 or not re.fullmatch(r"[A-Z2-7=]+", t):
        return None
    try:
        return base64.b32decode(t + "=" * (-len(t) % 8)).decode("utf-8")
    except (binascii.Error, UnicodeDecodeError, ValueError):
        return None


def _try_hex_bytes(s: str) -> bytes | None:
    t = re.sub(r"\s+", "", s)
    if len(t) < 4 or len(t) % 2 or not re.fullmatch(r"[0-9a-fA-F]+", t):
        return None
    return bytes.fromhex(t)


def _try_morse(s: str) -> str | None:
    t = s.strip()
    if not t or not re.fullmatch(r"[.\-/ ]+", t):
        return None
    words = []
    for w in re.split(r"\s*/\s*", t):
        letters = [MORSE_REV.get(x) for x in w.split()]
        if any(x is None for x in letters):
            return None
        words.append("".join(letters))
    return " ".join(words)


def _try_binary(s: str) -> str | None:
    t = s.strip()
    if not re.fullmatch(r"([01]{8}\s*)+", t):
        return None
    try:
        return bytes(int(b, 2) for b in t.split()).decode("utf-8")
    except (ValueError, UnicodeDecodeError):
        return None


NATO_REV = {w.upper(): w[0].upper() for w in (
    "Alfa Alpha Bravo Charlie Delta Echo Foxtrot Golf Hotel India Juliett Juliet Kilo Lima Mike November Oscar "
    "Papa Quebec Romeo Sierra Tango Uniform Victor Whiskey Xray X-ray Yankee Zulu").split()}


def _try_charcodes(s: str, base: int) -> str | None:
    """'116 104 101' (decimal) or '164 150 145' (octal) character codes."""
    toks = s.split()
    if len(toks) < 4 or not all(re.fullmatch(r"\d{2,3}", t) for t in toks):
        return None
    try:
        vals = [int(t, base) for t in toks]
    except ValueError:
        return None
    return "".join(map(chr, vals)) if all(32 <= v < 127 for v in vals) else None


def _try_nato(s: str) -> str | None:
    words = [w for w in re.split(r"\s*/\s*", s.strip()) if w]
    out = []
    for w in words:
        letters = [NATO_REV.get(t.upper()) for t in w.split()]
        if not letters or any(x is None for x in letters):
            return None
        out.append("".join(letters))
    return " ".join(out) if out and sum(len(w) for w in out) >= 3 else None


def _layer(text: str, keys: list[str]) -> list[tuple[str, str]]:
    out: list[tuple[str, str]] = [(text, "plain"), (text[::-1], "reverse"), (atbash(text), "atbash")]
    out += [(rot(text, n), f"rot{n}") for n in range(1, 26)]
    for k in keys:
        out.append((vigenere_decrypt(text, k), f"vigenere[{k}]"))
    for name, fn in (("base64", _try_b64), ("base32", _try_b32), ("morse", _try_morse), ("binary", _try_binary),
                     ("decimal", lambda t: _try_charcodes(t, 10)), ("octal", lambda t: _try_charcodes(t, 8)),
                     ("nato", _try_nato)):
        r = fn(text)
        if r:
            out.append((r, name))
    hb = _try_hex_bytes(text)
    if hb is not None:
        try:
            out.append((hb.decode("utf-8"), "hex"))
        except UnicodeDecodeError:
            pass
        for k in range(1, 256):
            x = bytes(b ^ k for b in hb)
            if all(32 <= b < 127 for b in x):
                out.append((x.decode("ascii"), f"xor{k}"))
    if "%" in text:
        out.append((unquote(text), "url"))
    return out


def payloads(text: str) -> list[str]:
    """Split a clue into likely ciphertext payloads (after a label colon, quoted, or whole)."""
    text = text[:MAX_INPUT]
    found = [text.strip()]
    if ":" in text:
        found.append(text.split(":", 1)[1].strip())
        found.append(text.rsplit(":", 1)[1].strip())
    found += re.findall(r'"([^"]{6,})"', text)
    seen, out = set(), []
    for f in found:
        if f and f not in seen:
            seen.add(f)
            out.append(f)
    return out


def find_keys(texts: list[str]) -> list[str]:
    keys: list[str] = []
    for t in texts:
        for m in re.finditer(r"\b(?:key|archive_key|keyword)\b(?:\s+(?:clue|is))?\s*[=:]?\s*([A-Za-z]{2,32})"
                             r"(\s+backwards|\s+reversed)?", t, re.I):
            k = m.group(1).upper()
            if k in ("IS", "A", "THE", "CLUE", "NOT", "IN", "OF"):
                continue
            for kk in ((k[::-1], k) if m.group(2) else (k, k[::-1]) if re.search(r"revers|backward", t, re.I) else (k,)):
                if kk not in keys:
                    keys.append(kk)
    return keys[:10]


def numeric_rank(c: "Candidate") -> tuple:
    """Lower is more plausible for code/pin evidence: fewest layers, structural decodes first."""
    return (c.method.count("+"), c.method == "reverse", c.method.startswith("xor"),
            not c.method.startswith(("hex", "base", "morse", "binary")))


STRICT_METHODS = {"nato", "morse", "binary", "decimal", "octal"}


def decode_all(texts: list[str], extra_keys: list[str] | None = None, top: int = 5) -> list[Candidate]:
    keys = list(dict.fromkeys(find_keys(texts) + [k.upper() for k in (extra_keys or [])]))
    cands: dict[str, Candidate] = {}
    originals = {p for raw in texts for p in payloads(raw)}

    def add(t: str, method: str) -> None:
        t = t.strip()
        if not t or method == "plain" or t in originals:
            return
        # strict-format decoders only fire on a full-format match: trust them over e.g. a mere reversal
        sc = english_score(t) + (3.0 if method in STRICT_METHODS else 0.0)
        if t not in cands or cands[t].score < sc:
            cands[t] = Candidate(t, method, sc)

    for raw in texts:
        for p in payloads(raw):
            for t1, m1 in _layer(p, keys):
                add(t1, m1)
                # second layer only for structural decodes that are not yet English
                if (m1 in ("base64", "base32", "hex", "reverse", "morse", "binary", "url", "atbash")
                        or m1.startswith("xor")) and t1 != p and english_score(t1) < 5.0:
                    for t2, m2 in _layer(t1, keys):
                        add(t2, f"{m1}+{m2}")
    ranked = sorted(cands.values(), key=lambda c: c.score, reverse=True)
    # numeric structural decodes (codes / pins) rank low on English but are high-value evidence
    numeric = [c for c in ranked[top:] if re.fullmatch(r"[\w\s:=-]*\d{3,}[\w\s]*", c.text)
               and not c.method.startswith(("rot", "atbash", "vigenere"))]
    numeric = sorted(numeric, key=numeric_rank)[:4]
    return ranked[:top] + numeric


def _worker(texts, extra_keys, top, q):  # pragma: no cover - runs in child
    q.put([(c.text, c.method, c.score) for c in decode_all(texts, extra_keys, top)])


def decode_all_safe(texts: list[str], extra_keys: list[str] | None = None, top: int = 5,
                    timeout_s: float = 3.0) -> list[Candidate]:
    """decode_all in a forked child with a hard timeout; on timeout/crash fall back to a cheap pass."""
    import multiprocessing as mp
    import queue as _q
    ctx = mp.get_context("fork")
    q = ctx.Queue()
    p = ctx.Process(target=_worker, args=(texts, extra_keys, top, q), daemon=True)
    p.start()
    try:
        rows = q.get(timeout=max(0.1, timeout_s))
        return [Candidate(*r) for r in rows]
    except (_q.Empty, EOFError, OSError):
        cheap = [t[:256] for t in texts][:8]
        out = []
        for raw in cheap:
            for t, m in ((raw[::-1], "reverse"), (atbash(raw), "atbash"), (_try_b64(raw) or "", "base64")):
                if t:
                    out.append(Candidate(t, m, english_score(t)))
        return sorted(out, key=lambda c: c.score, reverse=True)[:top]
    finally:
        if p.is_alive():
            p.kill()
        p.join(0.2)
