"""Deep JSON-schema validation + safe coercion for tool arguments (no external deps)."""
from __future__ import annotations

import re
from typing import Any

_INT_RE = re.compile(r"^[+-]?\d+$")
_NUM_RE = re.compile(r"^[+-]?\d+(\.\d+)?$")


def _types(spec: dict[str, Any]) -> list[str]:
    t = spec.get("type")
    if isinstance(t, str):
        return [t]
    if isinstance(t, list):
        return [x for x in t if isinstance(x, str)]
    out: list[str] = []
    for alt in (spec.get("anyOf") or spec.get("oneOf") or []):
        if isinstance(alt, dict):
            out += _types(alt)
    return out


def _is(v: Any, t: str) -> bool:
    if t == "string":
        return isinstance(v, str)
    if t == "integer":
        return isinstance(v, int) and not isinstance(v, bool)
    if t == "number":
        return isinstance(v, (int, float)) and not isinstance(v, bool)
    if t == "boolean":
        return isinstance(v, bool)
    if t == "object":
        return isinstance(v, dict)
    if t == "array":
        return isinstance(v, list)
    if t == "null":
        return v is None
    return True


def check(v: Any, spec: dict[str, Any], path: str = "$", depth: int = 0) -> str | None:
    """Return an error string or None. Handles type/anyOf, enum/const, nested objects/arrays, bounds."""
    if depth > 8 or not isinstance(spec, dict):
        return None
    alts = spec.get("anyOf") or spec.get("oneOf")
    if alts and not spec.get("type"):
        errs = [check(v, a, path, depth + 1) for a in alts if isinstance(a, dict)]
        return None if any(e is None for e in errs) or not errs else errs[0]
    types = _types(spec)
    if types and not any(_is(v, t) for t in types):
        return f"{path}: expected {'|'.join(types)}, got {type(v).__name__}"
    if "enum" in spec and v not in spec["enum"]:
        return f"{path}: not in enum {spec['enum']}"
    if "const" in spec and v != spec["const"]:
        return f"{path}: must equal {spec['const']!r}"
    if isinstance(v, str):
        if len(v) < int(spec.get("minLength", 0)):
            return f"{path}: too short"
        if "maxLength" in spec and len(v) > int(spec["maxLength"]):
            return f"{path}: too long"
        if "pattern" in spec:
            try:
                if not re.search(spec["pattern"], v):
                    return f"{path}: pattern mismatch"
            except re.error:
                pass
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        if "minimum" in spec and v < spec["minimum"]:
            return f"{path}: below minimum"
        if "maximum" in spec and v > spec["maximum"]:
            return f"{path}: above maximum"
    if isinstance(v, dict):
        props = spec.get("properties") or {}
        for r in spec.get("required") or []:
            if r not in v:
                return f"{path}.{r}: missing"
        for k, sub in v.items():
            if k in props:
                e = check(sub, props[k], f"{path}.{k}", depth + 1)
                if e:
                    return e
            elif props and spec.get("additionalProperties") is False:
                return f"{path}.{k}: unexpected"
    if isinstance(v, list) and isinstance(spec.get("items"), dict):
        for i, sub in enumerate(v):
            e = check(sub, spec["items"], f"{path}[{i}]", depth + 1)
            if e:
                return e
    return None


def coerce(v: Any, spec: dict[str, Any]) -> Any:
    """Best-effort lossless coercion toward the declared type (e.g. '4821' -> 4821 for integer)."""
    if not isinstance(spec, dict) or check(v, spec) is None:
        return v
    types = _types(spec)
    for t in types:
        if t == "integer" and isinstance(v, str) and _INT_RE.match(v.strip()):
            return int(v.strip())
        if t == "integer" and isinstance(v, float) and v.is_integer():
            return int(v)
        if t == "number" and isinstance(v, str) and _NUM_RE.match(v.strip()):
            return float(v.strip())
        if t == "string" and isinstance(v, (int, float)) and not isinstance(v, bool):
            return str(v)
        if t == "boolean" and isinstance(v, str) and v.lower() in ("true", "false"):
            return v.lower() == "true"
        if t == "array" and not isinstance(v, list):
            return [v]
    if "enum" in spec and isinstance(v, str):
        for e in spec["enum"]:
            if isinstance(e, str) and e.lower() == v.strip().lower():
                return e
    return v


def coerce_args(schema: dict[str, Any], args: dict[str, Any]) -> dict[str, Any]:
    props = (schema or {}).get("properties") or {}
    return {k: coerce(v, props[k]) if k in props else v for k, v in args.items()}
